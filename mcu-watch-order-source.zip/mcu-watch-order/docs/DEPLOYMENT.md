# AWS 部署与后续接续

## 本次实际环境

已发现本机 SSH 别名 `tokyo`，身份文件名称包含 `ap-northeast-1`；尚不能据此确认是 EC2 还是 Lightsail。未发现可直接使用的 AWS CLI。只读 SSH 连接尝试被执行环境以 `Operation not permitted` 拒绝，尚未建立服务器会话，因此未检查远端端口、域名、TLS、目录或其他服务，也没有修改 AWS。

必须在允许连接既有服务器的环境中继续；不要新建付费资源，不要关闭安全限制以绕过当前执行环境。

## 先检查既有资源

通过现有授权 SSH 进入 `tokyo`，只读检查：运行中服务、监听端口、Node 版本、Nginx/Caddy 配置、可用 HTTPS server_name、证书域名与有效期、磁盘及内存。确认 8787 空闲、`/opt/mcu-watch-order` 和 `/var/lib/mcu-timeline` 未被其他服务占用后再部署。

若目标不是 Nginx，按已有代理的语法追加等价路由。不要安装第二个代理占用 80/443，也不要覆盖现有站点。

## Trakt 应用

开发者入口：https://developer.trakt.tv/apps

应用名称：`Personal MCU Timeline for Rex`。用途为个人 MCU 观影导航和本人观看记录只读同步。官网填实际 HTTPS origin；回调填同域的 `/mcu/oauth/callback`。选免费 Standard。优先使用本人已有 Google 登录，由本人完成必要的账号条款、GitHub 关联及 OAuth 授权。不可直接复用 Rex 自身 OAuth Token 或其他应用的 Client ID。

**应用必须注册实际已控制的 HTTPS 回调。不要把示例域名提交成真实应用配置。**

## 部署步骤

以下是供接续执行的步骤，本次没有运行远端变更。

1. 将本源码目录放到审计确认的新目录 `/opt/mcu-watch-order`；建立独立无登录用户 `mcu-timeline`。
2. 使用服务器现有 Node.js 22+；没有合适版本时先检查现有运行时，不能替换其他服务正在使用的 Node。
3. 创建 root 所有、权限 0600 的 `/etc/mcu-timeline.env`。参照 `.env.example`，在服务器私有终端执行 `node scripts/secrets.mjs` 生成三枚不同密钥；不把输出复制到聊天、日志或 Git。
4. 填入 Trakt Client ID、实际 `PUBLIC_ORIGIN`、准确 `OAUTH_REDIRECT_URI`。Client Secret 若官方提供，仅在服务端使用；PKCE 授权本身不需要 Client Secret。可不填 TMDB_BEARER，先使用 Rex 自己配置的 TMDB 能力。
5. 将 `deploy/mcu-timeline.service` 放到 systemd，核对实际 Node 路径；执行 daemon-reload 后启动这一项服务。只有该服务可写运行时目录。
6. 在已验证的现有 HTTPS server block 中追加 `deploy/nginx-location.conf`，不改其他 location。先 `nginx -t`，通过后仅 reload。保留修改前备份和恢复方法。
7. 从服务器 loopback 检查 `/mcu/healthz`，再通过公网 HTTPS 检查同一路径。确认无密钥访问 `/mcu/v1/queue` 为 401，公网 `/mcu/admin/status` 为 404。
8. 在服务目录以相同环境文件启动 `scripts/authorize.mjs`，它调用正在运行的服务，不自行写 Token。由本人打开输出的官方 Trakt 授权 URL，完成授权。URL 10 分钟过期，state 单次使用。
9. 运行 `scripts/update.mjs` 请求一次初始化，检查状态成功、媒体 ID 全部核实、分集列表有效。该脚本需要注入同一私有环境，不要 `source` 不可信内容。
10. 真实 HTTPS 导入地址只有验证后才可交付，路径为实际 origin 下 `/mcu/widget.js`。Rex 模块参数填实际 `/mcu` API 地址及独立只读访问密钥；不要填管理密钥或 Trakt Token。
11. 在本人 Rex 验收最早待看项、逐集指向、原生详情和媒体库匹配，再验证 HTTPS 导入及刷新。不能为了验收改写本人观看历史；使用已存在的记录进行只读检查。

## 自动维护与恢复

服务启动时更新一次目录；正常每天检查官方时间线和元数据，失败按至少 5 分钟与提供方 Retry-After 较长者退避。每分钟检查是否到期，不会每分钟下载目录。观看记录只在请求时按默认 10 分钟有效期同步，可主动刷新。多个并发请求合并一次同步。

元数据刷新失败不替换最近有效清单，观看同步失败不替换最近有效观看记录。令牌文件 AES-GCM 加密，目录原子提交并同步到磁盘。systemd 在异常退出后自动重启；服务锁避免多个本地实例竞争单次刷新令牌。

备份 `/var/lib/mcu-timeline` 和 `/etc/mcu-timeline.env`，分开保管加密密钥。恢复前停止该单项服务，恢复目录及权限后启动；不要同时运行两个写入同一数据目录的实例。

## 回滚

停止并停用 `mcu-timeline.service`；从既有 HTTPS 站点只删除本次新增的 `/mcu/` 路由段，校验后 reload；保留运行时目录备份。不得删除或重写任何其他站点、证书或服务。
