# gh 发布接续

2026-11-08：已创建公开仓库 `tzb360/rex-mcu-watch-order`。根据本人最新要求，文件发布改用本机 `gh`，不通过网页上传。

当前执行环境中的 `gh 2.103.2` 无法连接 `api.github.com`。只读仓库查询和发布脚本的首个只读请求均失败，尚未通过 gh 上传任何文件。`gh auth status` 同时报告登录校验失败，但由于 API 网络不可达，不能据此断定凭据过期，也没有删除或更换现有凭据。

请在网络可用的本机终端运行：

```sh
node /Users/tianzibo/Documents/Codex/2026-11-08/new-chat-4/mcu-watch-order/scripts/publish-gh.mjs
```

从源码包解压到其他位置时，运行相应位置的 `scripts/publish-gh.mjs` 即可，脚本自行定位工程目录。

脚本先通过 gh 核实仓库、Public 可见性和 main 分支，构建本地版，再生成不包含运行时数据的发布包。它使用 GitHub Git Data API 上传公开文件，创建一笔提交，以不强推方式更新 main，并拒绝覆盖发布期间出现的其他提交。

只发布四个根目录文件：

- `mcu-watch-order-local.js`
- `timeline.seed.json`
- `mcu-watch-order-source.zip`
- `README.md`

成功后会检查两条稳定 Raw 地址的 HTTP 状态和 SHA-256，只有文件内容与本地发布文件完全一致才报告校验通过：

```text
https://raw.githubusercontent.com/tzb360/rex-mcu-watch-order/main/mcu-watch-order-local.js
https://raw.githubusercontent.com/tzb360/rex-mcu-watch-order/main/timeline.seed.json
```

**上面是目标地址，本次尚未通过 gh 完成发布，不能视为已经可用。**

脚本不读取 gh Token、浏览器 Cookie 或 Rex 模块存储，不修改 Trakt 观看历史，不配置服务器。若上传成功但 Raw 缓存暂未刷新，会明确区分“已提交”和“Raw 校验未通过”，不会谎报链接可用。
