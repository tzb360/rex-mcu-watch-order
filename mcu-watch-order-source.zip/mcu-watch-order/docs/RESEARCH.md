# 技术调查与数据来源

核实日期：2026-11-08。以下链接均为调查时实际读取的公开资料或页面。

## Rex 与 Forward

主要依据：

- https://github.com/baranwang/rex-widget-libs
- https://github.com/baranwang/rex-widget-libs/blob/main/packages/libs/src/env/metadata.ts
- https://github.com/baranwang/rex-widget-libs/blob/main/packages/libs/src/env/video.ts
- https://github.com/baranwang/rex-widget-libs/blob/main/packages/libs/src/widget-adaptor.ts
- https://github.com/baranwang/rex-widget-libs/blob/main/packages/rslib-plugin/src/encrypt.ts
- https://github.com/InchStudio/ForwardWidgets/blob/main/README.md
- https://github.com/Meilieage/REX-mod/blob/main/modules/meilieage-discover.js

Rex 工具库调查时主分支树 SHA：`2b7430712e294a173c7f29bef9730ba4ca03ce46`。

`metadata.ts` blob SHA：`942d84241b20a5ed70f2111f7ed1658455a02859`。

`video.ts` blob SHA：`504903a6bef55b132177f29af3ba9603ed4c263b`。

普通列表在 `WidgetMetadata.modules` 声明函数名，返回 VideoItem 数组，不填写未知的 list 类型；类型定义仅为弹幕、字幕、播放资源列出特定 type。`globalParams`、`params`、`cacheDuration` 受公开定义支持。卡片标识采用 `type: tmdb`、`id: movie.<ID>` 或 `tv.<ID>`，不附加私造的季号后缀。

接口提供 `Widget.http.get`、`Widget.tmdb.get`、`Widget.storage`。异步与同步 storage 均通过 await 兼容。HTTP 结果兼容 `statusCode` 和 `status`，不把 Node fetch 当作客户端运行接口。模块脚本不含 ES module 导入或导出。

参考项目自身明确写着“REX 客户端兼容性待实机验证”，因此仅作公开实现参考，不能代替 Rex 原生验收。

本机安装 Rex `CFBundleShortVersionString=1.1`。真实文件导入时 `requiredVersion: 1.1` 被客户端以“当前版本过低”拒绝；改成公开示例的 `0.0.1` 后成功。已观察到模块标题、0.1.0 版本、核心模块、缓存 0 秒及 4 个参数说明。App 的版本号与该兼容字段不能直接等同。

未核实：同一 TMDB ID 的多季卡片是否被 UI 去重、原生详情是否覆盖进度文案、具体客户端刷新入口和 HTTPS 导入后的更新行为。

参考 `platform.originals.ui.fix.js` 只检查到 REXENC v2 / rex-1 / A256GCM 信封头。工具库存在 `validateEncryptEnvelope` 与官方单向加密请求，但本次所读公开接口未提供合法反向源码检查方法；没有解密，也没有根据文件名猜测其功能。

## MCU 官方时间线

主要来源：https://www.marvel.com/articles/movies/mcu-timeline-order-disney-plus

2026-11-08 使用真实浏览器读取，该页显示发布日期 2026-10-22，完整清单实际为 81 项，从 Eyes of Wakanda 到 VisionQuest。读取的是标题 `MCU Complete Timeline` 后的完整列表，而非网站推荐区或上映顺序清单。普通检索抓取曾返回 403，但浏览器正常展示官方正文，因此服务器是否能直接读取仍需在 AWS 实测；不能把浏览器可读等同于服务器抓取必定成功。

Disney+ 的官方完整时间线入口可从该页进入。地区目录与链接会变化；本实现不需要登录 Disney+ 或购买订阅。

处理原则：

- 保留官方的分季顺序，不整剧挤在首次出现的位置。
- Loki、What If…?、Marvel Zombies、Deadpool & Wolverine、The Fantastic Four: First Steps 标记多元宇宙/推荐位置，不杜撰统一故事年份。
- 跨年代作品保留官方整体位置，当前不按无来源的逐集推断重排。
- 官网列出的 Daredevil S1/Jessica Jones S1/Luke Cage S1 等部分超链接尾部指向其他季；按可见季标签识别，保留来源依据。
- 官网 Spider-Man: Far From Home 的链接指向 No Way Home 页面；依可见片名进行独立媒体身份匹配，不使用错误链接识别 ID。
- Team Thor / Team Darryl、Agents of S.H.I.E.L.D.、Agent Carter 长篇剧等未见于本次官方完整清单，不凭同品牌强行加入；Agent Carter One-Shot 已纳入。
- Spider-Man: Brand New Day 未列在此次读取的完整清单内，不编造其时间线位置；后续官方清单更新后再按规则纳入。
- 稳定 ID 为插件自有身份；外部 ID 必须由 API 唯一匹配后写入，不仅凭中文名称。

## Trakt 当前规范

- https://developer.trakt.tv/docs/create-an-app
- https://developer.trakt.tv/docs/authentication-oauth
- https://developer.trakt.tv/docs/pkce
- https://developer.trakt.tv/docs/api-use-policy
- https://github.com/trakt/trakt-api/discussions/775
- https://github.com/trakt/trakt-api/blob/master/projects/api/src/contracts/oauth/index.ts
- https://github.com/trakt/trakt-api/blob/master/projects/api/src/contracts/sync/index.ts
- https://github.com/trakt/trakt-api/blob/master/projects/api/src/contracts/search/index.ts
- https://github.com/trakt/trakt-api/blob/master/projects/api/src/contracts/shows/index.ts
- https://github.com/trakt/trakt-api/blob/master/projects/api/src/contracts/users/schema/response/watchedShowsResponseSchema.ts
- https://github.com/trakt/trakt-api/blob/master/projects/api/src/contracts/users/schema/response/watchingResponseSchema.ts

2026 年当前规范要求创建应用前关联已验证 GitHub。Standard 免费方案可用于个人工具，不创建付费计划。

OAuth 请求使用 `https://auth.trakt.tv`；普通 API 使用 `https://api.trakt.tv`。采用 PKCE + state，HTTPS 回调，令牌仅保存于服务端。访问令牌约 7 天有效，刷新令牌单次使用、成功后必须保存新令牌；实现单进程串行刷新与原子写入。

观看接口使用 `/sync/watched/movies` 和 `/sync/watched/shows?extended=progress`，均显式分页。当前公告明确剧集默认不再包含逐集进度，`extended=progress` 上限比普通分页更低，不能按请求的页大小判断最后一页。实现遵循总页数头，无可靠页数时一直读到空数组，重复页面视为错误并保留旧快照。

暂停进度来自 `/sync/playback`，当前播放来自 `/users/me/watching`。不使用观看历史反推“正在播放”。未对 Trakt 执行任何观看历史写操作。

公开仓库的部分 schema 与较新的分页公告存在滞后，因此分页规则优先采用官方更新公告，最终响应形状仍需本人真实账户 API 联调。
