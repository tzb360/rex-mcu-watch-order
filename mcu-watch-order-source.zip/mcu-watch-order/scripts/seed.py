import json,re
from pathlib import Path
# Official Marvel article, rendered list read 2026-11-08. Season labels take
# precedence over erroneous hyperlink season suffixes in the official article.
rows='''Eyes of Wakanda|瓦坎达之眼|tv|2025|1
Captain America: The First Avenger|美国队长|movie|2011
Marvel Studios One Shot: Agent Carter|探员卡特|movie|2013
Captain Marvel|惊奇队长|movie|2019
Iron Man|钢铁侠|movie|2008
Iron Man 2|钢铁侠2|movie|2010
The Incredible Hulk|无敌浩克|movie|2008
Marvel Studios One Shot: A Funny Thing Happened on the Way to Thor’s Hammer|寻找雷神锤子路上发生的趣事|movie|2011
Thor|雷神|movie|2011
Marvel Studios One Shot: The Consultant|顾问|movie|2011
The Avengers|复仇者联盟|movie|2012
Marvel Studios One Shot: Item 47|47号物品|movie|2012
Thor: The Dark World|雷神2：黑暗世界|movie|2013
Iron Man 3|钢铁侠3|movie|2013
Marvel Studios One Shot: All Hail the King|王者万岁|movie|2014
Captain America: The Winter Soldier|美国队长2：冬日战士|movie|2014
Guardians of the Galaxy|银河护卫队|movie|2014
Guardians of the Galaxy Vol. 2|银河护卫队2|movie|2017
I Am Groot|我是格鲁特|tv|2022|1
I Am Groot|我是格鲁特|tv|2022|2
Daredevil|夜魔侠|tv|2015|1
Jessica Jones|杰西卡·琼斯|tv|2015|1
Avengers: Age of Ultron|复仇者联盟2：奥创纪元|movie|2015
Ant-Man|蚁人|movie|2015
Daredevil|夜魔侠|tv|2015|2
Luke Cage|卢克·凯奇|tv|2016|1
Iron Fist|铁拳|tv|2017|1
The Defenders|捍卫者联盟|tv|2017|1
Captain America: Civil War|美国队长3|movie|2016
Black Widow|黑寡妇|movie|2021
Black Panther|黑豹|movie|2018
Spider-Man: Homecoming|蜘蛛侠：英雄归来|movie|2017
The Punisher|惩罚者|tv|2017|1
Doctor Strange|奇异博士|movie|2016
Jessica Jones|杰西卡·琼斯|tv|2015|2
Luke Cage|卢克·凯奇|tv|2016|2
Iron Fist|铁拳|tv|2017|2
Daredevil|夜魔侠|tv|2015|3
Thor: Ragnarok|雷神3：诸神黄昏|movie|2017
The Punisher|惩罚者|tv|2017|2
Jessica Jones|杰西卡·琼斯|tv|2015|3
Ant-Man and the Wasp|蚁人2：黄蜂女现身|movie|2018
Avengers: Infinity War|复仇者联盟3：无限战争|movie|2018
Avengers: Endgame|复仇者联盟4：终局之战|movie|2019
Loki|洛基|tv|2021|1
What If…?|假如…？|tv|2021|1
Marvel Zombies|漫威丧尸|tv|2025|1
WandaVision|旺达幻视|tv|2021|1
Shang-Chi and the Legend of the Ten Rings|尚气与十环传奇|movie|2021
The Falcon and the Winter Soldier|猎鹰与冬兵|tv|2021|1
Spider-Man: Far From Home|蜘蛛侠：英雄远征|movie|2019
Eternals|永恒族|movie|2021
Spider-Man: No Way Home|蜘蛛侠：英雄无归|movie|2021
Doctor Strange in the Multiverse of Madness|奇异博士2：疯狂多元宇宙|movie|2022
Hawkeye|鹰眼|tv|2021|1
Moon Knight|月光骑士|tv|2022|1
Black Panther: Wakanda Forever|黑豹2|movie|2022
Echo|回声|tv|2024|1
She-Hulk: Attorney at Law|女浩克|tv|2022|1
Ms. Marvel|惊奇少女|tv|2022|1
Thor: Love and Thunder|雷神4：爱与雷霆|movie|2022
Ironheart|钢铁之心|tv|2025|1
Werewolf By Night|暗夜狼人|movie|2022
The Guardians of the Galaxy Holiday Special|银河护卫队：圣诞特别篇|movie|2022
Ant-Man and the Wasp: Quantumania|蚁人与黄蜂女：量子狂潮|movie|2023
Guardians of the Galaxy Vol. 3|银河护卫队3|movie|2023
Secret Invasion|秘密入侵|tv|2023|1
The Marvels|惊奇队长2|movie|2023
Loki|洛基|tv|2021|2
What If…?|假如…？|tv|2021|2
Deadpool & Wolverine|死侍与金刚狼|movie|2024
Agatha All Along|女巫阿加莎|tv|2024|1
What If…?|假如…？|tv|2021|3
Daredevil: Born Again|夜魔侠：重生|tv|2025|1
Captain America: Brave New World|美国队长4|movie|2025
Thunderbolts*|雷霆特攻队*|movie|2025
The Fantastic Four: First Steps|神奇四侠：初露锋芒|movie|2025
Wonder Man|奇迹人|tv|2026|1
Daredevil: Born Again|夜魔侠：重生|tv|2025|2
The Punisher: One Last Kill|惩罚者：最后一击|movie|2026
VisionQuest|幻视任务|tv|2026|1'''
source='https://www.marvel.com/articles/movies/mcu-timeline-order-disney-plus'
entries=[]
for i,row in enumerate(rows.splitlines(),1):
    title,zh,kind,year,*season=row.split('|')
    s=int(season[0]) if season else None
    slug=re.sub('[^a-z0-9]+','-',title.lower()).strip('-')
    branch=title in ['Loki','What If…?','Marvel Zombies','Deadpool & Wolverine','The Fantastic Four: First Steps']
    entry=dict(stableId='mcu-'+slug+('-s'+str(s) if s else ''),title=zh,originalTitle=title,mediaType=kind,searchYear=int(year),season=s,episodeRange=None,tmdbId=None,imdbId=None,traktId=None,timelineOrder=i*10,timelineEra='官方完整时间线第'+str(i)+'位'+('（推荐观影位置）' if branch else '（主体故事顺序）'),universe='multiverse' if branch else 'Earth-616',releaseDate=None,availabilityStatus='pending_metadata',chronologySource=[dict(url=source,publishedAt='2026-10-22',basis='rendered-list-label',position=i)],lastVerifiedAt='2026-11-08',metadataVerifiedAt=None)
    entry['officialLabel']=title+(' S'+str(s) if s and title in ['I Am Groot','Daredevil','Jessica Jones','Luke Cage','Iron Fist','The Punisher','Loki','What If…?','Daredevil: Born Again'] else '')
    if title.startswith('Marvel Studios One Shot: '):
        entry['searchAliases']=[title.replace('Marvel Studios One Shot: ','Marvel One-Shot: ')]
    if title in ['Daredevil','Jessica Jones','Luke Cage','Iron Fist','The Defenders','The Punisher']:
        entry['searchAliases']=["Marvel's "+title.removeprefix('The ')]
    entries.append(entry)
root=Path(__file__).resolve().parents[1]
(root/'data/timeline.seed.json').write_text(json.dumps(dict(schemaVersion=1,version='2026-11-08.1',sourcePublishedAt='2026-10-22',updatedAt='2026-11-08T00:00:00Z',metadataStatus='requires-live-resolution',entries=entries),ensure_ascii=False,indent=2)+'\n')
print('Wrote',len(entries),'official timeline segments; no unverified external IDs assigned.')
