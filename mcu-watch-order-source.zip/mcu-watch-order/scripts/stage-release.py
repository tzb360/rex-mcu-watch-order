from pathlib import Path
import hashlib
import json
import shutil
import zipfile

root = Path(__file__).resolve().parents[1]
output = root.parent / 'outputs' / 'rex-release'
output.mkdir(parents=True, exist_ok=True)
for source, destination in [
    (root / 'widget/mcu-watch-order-local.js', 'mcu-watch-order-local.js'),
    (root / 'data/timeline.public.json', 'timeline.seed.json'),
    (root / 'docs/PUBLIC_README.md', 'README.md'),
]:
    shutil.copyfile(source, output / destination)

files = [p for p in sorted(root.rglob('*')) if p.is_file()
         and not any(part in ('.git', 'node_modules', 'runtime') for part in p.relative_to(root).parts)
         and p.name not in ('.env', 'SHA256SUMS.json')
         and p.suffix not in ('.pem', '.key', '.log')]
manifest = {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
(root / 'SHA256SUMS.json').write_text(json.dumps(manifest, indent=2) + '\n')
archive = output / 'mcu-watch-order-source.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as z:
    for p in [*files, root / 'SHA256SUMS.json']:
        info = zipfile.ZipInfo('mcu-watch-order/' + str(p.relative_to(root)), (2026, 11, 8, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o100644 << 16
        z.writestr(info, p.read_bytes())
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert not any(name.endswith('/.env') or '/runtime/' in name for name in z.namelist())
print(json.dumps({'output': str(output), 'files': [p.name for p in output.iterdir()]}))
