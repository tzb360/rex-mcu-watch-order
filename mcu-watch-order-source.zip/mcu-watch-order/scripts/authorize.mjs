import { config } from '../src/config.mjs';
const c = config();
const response = await fetch('http://127.0.0.1:' + c.port + '/mcu/admin/oauth/start', { method: 'POST', headers: { Authorization: 'Bearer ' + c.adminKey } });
const data = await response.json();
if (!response.ok) throw new Error(data.error);
console.log('Open personally in a browser (expires in 10 minutes):\n' + data.authorizationUrl);
