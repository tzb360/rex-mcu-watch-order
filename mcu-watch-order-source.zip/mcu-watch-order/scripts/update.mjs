import { config } from '../src/config.mjs';
const c = config();
const response = await fetch('http://127.0.0.1:' + c.port + '/mcu/admin/update', { method: 'POST', headers: { Authorization: 'Bearer ' + c.adminKey }, signal: AbortSignal.timeout(600000) });
const result = await response.json();
if (!response.ok) throw new Error(result.error);
console.log(JSON.stringify(result));
