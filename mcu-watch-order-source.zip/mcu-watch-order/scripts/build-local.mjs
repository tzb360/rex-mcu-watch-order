import { readFile, writeFile } from 'node:fs/promises';
import vm from 'node:vm';
let entry = await readFile('widget/local-entry.js', 'utf8');
const out = [entry];
for (const file of ['src/trakt.mjs', 'src/progress.mjs', 'src/timeline.mjs']) {
  let code = await readFile(file, 'utf8');
  code = code.replace(/^import .*;\n/gm, '').replace(/^export /gm, '');
  code = code.replaceAll('new URLSearchParams(', 'new MCUQuery(');
  // This personal app has no issued Client Secret; omit legacy secret handling.
  code = code.replace('      if (this.clientSecret) body.client_secret = this.clientSecret;\n', '');
  code = code.replace(/AbortSignal\.timeout\(\d+\)/g, 'undefined');
  code = code.replace("createHash('sha256').update(JSON.stringify(entries)).digest('hex').slice(0, 12)", 'mcuVersion(JSON.stringify(entries))');
  code = code.replace("this.seedLoader = seedLoader || (async () => JSON.parse(await readFile(new URL('../data/timeline.seed.json', import.meta.url), 'utf8')));", 'this.seedLoader = seedLoader;');
  if (/^import |^export |\bimport\.meta|\breadFile\(|\bcreateHash\(|\bAbortSignal\b/m.test(code)) throw new Error('Unsupported Node dependency in ' + file);
  out.push(code);
}
const source = out.join('\n\n');
new vm.Script(source);
await writeFile('widget/mcu-watch-order-local.js', source);
console.log('Built standalone local Rex widget; no token or server secret included.');
