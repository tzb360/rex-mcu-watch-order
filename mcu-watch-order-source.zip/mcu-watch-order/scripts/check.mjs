import { readFile, readdir } from 'node:fs/promises';
import { spawnSync } from 'node:child_process';
import vm from 'node:vm';
import assert from 'node:assert/strict';
for (const folder of ['src', 'scripts', 'tests']) for (const filename of await readdir(folder)) {
  if (!filename.endsWith('.mjs')) continue;
  const result = spawnSync(process.execPath, ['--check', folder + '/' + filename], { encoding: 'utf8' });
  if (result.status) throw new Error(result.stderr);
}
const js = await readFile('widget/mcu-watch-order.js', 'utf8');
const context = vm.createContext({}); vm.runInContext(js, context);
assert.equal(context.WidgetMetadata.id, 'personal.mcu.timeline');
assert.equal(context.WidgetMetadata.modules.length, 1);
assert(!/^\s*(?:export|import)\s/m.test(js));
assert(!/refresh_token\s*[:=]|access_token\s*[:=]|client_secret\s*[:=]/.test(js));
const seed = JSON.parse(await readFile('data/timeline.seed.json', 'utf8'));
assert.equal(new Set(seed.entries.map(e => e.stableId)).size, seed.entries.length);
assert(seed.entries.every(e => e.chronologySource?.length && e.lastVerifiedAt));
console.log('Syntax, widget metadata, stable IDs and public artifact checks passed.');
