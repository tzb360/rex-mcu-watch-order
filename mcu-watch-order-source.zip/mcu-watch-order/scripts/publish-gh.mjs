import { readFile } from 'node:fs/promises';
import { execFileSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { resolve, join } from 'node:path';
import { createHash } from 'node:crypto';

// Only this already-created public repository and these four public files.
// No gh auth token commands, browser cookies or Rex storage are accessed.
const repository = 'tzb360/rex-mcu-watch-order';
const root = fileURLToPath(new URL('..', import.meta.url));
const release = resolve(root, '../outputs/rex-release');
const filenames = ['README.md', 'mcu-watch-order-local.js', 'timeline.seed.json', 'mcu-watch-order-source.zip'];
const hash = bytes => createHash('sha256').update(bytes).digest('hex');
function gh(method, endpoint, body) {
  const args = ['api', endpoint, '--method', method, '-H', 'Accept: application/vnd.github+json'];
  if (body !== undefined) args.push('--input', '-');
  try {
    const out = execFileSync('gh', args, { encoding: 'utf8', input: body === undefined ? undefined : JSON.stringify(body), maxBuffer: 20 * 1024 * 1024, timeout: 60000, stdio: ['pipe', 'pipe', 'pipe'] });
    return out.trim() ? JSON.parse(out) : null;
  } catch (error) {
    throw new Error('gh 请求失败（' + method + ' ' + endpoint + '）：\n' + String(error.stderr || error.message).trim().slice(0, 1800));
  }
}
async function main() {
  // Verify access before generating objects or changing any remote data.
  const repo = gh('GET', 'repos/' + repository);
  if (repo.full_name !== repository || repo.private !== false || repo.default_branch !== 'main') throw new Error('仓库身份、可见性或默认分支与已核实配置不同，已停止。');
  const head = gh('GET', 'repos/' + repository + '/git/ref/heads/main');
  const commit = gh('GET', 'repos/' + repository + '/git/commits/' + head.object.sha);
  execFileSync(process.execPath, ['scripts/build-local.mjs'], { cwd: root, stdio: 'inherit' });
  execFileSync('python3', ['scripts/stage-release.py'], { cwd: root, stdio: 'inherit' });
  const bytes = new Map();
  for (const filename of filenames) bytes.set(filename, await readFile(join(release, filename)));
  const js = bytes.get('mcu-watch-order-local.js').toString('utf8');
  if (/MCU_ADMIN_KEY|MCU_ACCESS_KEY|(?:access_token|refresh_token)\s*[:=]\s*['"][^'"]+['"]/.test(js)) throw new Error('公开 JS 检测到疑似私有凭据，已停止。');
  const zip = gh('POST', 'repos/' + repository + '/git/blobs', { content: bytes.get('mcu-watch-order-source.zip').toString('base64'), encoding: 'base64' });
  const tree = gh('POST', 'repos/' + repository + '/git/trees', {
    base_tree: commit.tree.sha,
    tree: filenames.map(filename => ({ path: filename, mode: '100644', type: 'blob', ...(filename.endsWith('.zip') ? { sha: zip.sha } : { content: bytes.get(filename).toString('utf8') }) }))
  });
  let published = head.object.sha;
  if (tree.sha !== commit.tree.sha) {
    const next = gh('POST', 'repos/' + repository + '/git/commits', { message: 'Publish MCU Watch Order 0.2.4 with native Rex metadata', tree: tree.sha, parents: [head.object.sha] });
    const current = gh('GET', 'repos/' + repository + '/git/ref/heads/main');
    if (current.object.sha !== head.object.sha) throw new Error('发布期间 main 已变化，未更新分支。请检查远端改动后重试。');
    gh('PATCH', 'repos/' + repository + '/git/refs/heads/main', { sha: next.sha, force: false });
    published = next.sha;
  }
  console.log('gh 已发布提交：' + published);
  const verified = [];
  for (const filename of ['mcu-watch-order-local.js', 'timeline.seed.json']) {
    const url = 'https://raw.githubusercontent.com/' + repository + '/main/' + filename;
    let lastError;
    for (let attempt = 0; attempt < 8; attempt++) {
      try {
        const response = await fetch(url, { signal: AbortSignal.timeout(20000), redirect: 'error' });
        if (!response.ok) throw new Error('HTTP ' + response.status);
        const received = Buffer.from(await response.arrayBuffer());
        if (hash(received) !== hash(bytes.get(filename))) throw new Error('Raw 内容与本地发布文件不一致，可能仍在更新缓存');
        verified.push({ filename, url, sha256: hash(received) }); lastError = null; break;
      } catch (error) { lastError = error; if (attempt < 7) await new Promise(done => setTimeout(done, 5000)); }
    }
    if (lastError) throw new Error('文件已上传，但 Raw 校验未通过：' + url + '\n' + lastError.message);
  }
  console.log(JSON.stringify({ commit: published, verified }, null, 2));
}
main().catch(error => { console.error(error.message); process.exitCode = 1; });
