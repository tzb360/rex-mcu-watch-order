import { randomBytes } from 'node:crypto';
// Run privately on the server; never commit output or put it in public JS.
for (const name of ['MCU_ACCESS_KEY', 'MCU_ADMIN_KEY']) console.log(name + '=' + randomBytes(32).toString('base64url'));
console.log('MCU_ENCRYPTION_KEY=' + randomBytes(32).toString('base64'));
