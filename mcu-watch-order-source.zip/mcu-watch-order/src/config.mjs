import { resolve } from 'node:path';
export function config(env = process.env) {
  const c = {
    host: env.HOST || '127.0.0.1', port: Number(env.PORT || 8787), dir: resolve(env.DATA_DIR || './runtime'),
    accessKey: env.MCU_ACCESS_KEY, adminKey: env.MCU_ADMIN_KEY, encryptionKey: env.MCU_ENCRYPTION_KEY,
    clientId: env.TRAKT_CLIENT_ID, clientSecret: env.TRAKT_CLIENT_SECRET, origin: env.PUBLIC_ORIGIN,
    redirectUri: env.OAUTH_REDIRECT_URI, tmdbBearer: env.TMDB_BEARER,
    ttl: Math.min(900, Math.max(300, Number(env.WATCH_CACHE_SECONDS || 600))) * 1000
  };
  for (const k of ['accessKey', 'adminKey']) if (!c[k] || c[k].length < 32) throw new Error('Missing strong configuration: ' + k);
  if (c.accessKey === c.adminKey) throw new Error('Read and admin keys must differ');
  if (!c.clientId) throw new Error('TRAKT_CLIENT_ID required');
  if (!c.origin || new URL(c.origin).protocol !== 'https:') throw new Error('PUBLIC_ORIGIN must use HTTPS');
  if (!c.redirectUri || new URL(c.redirectUri).origin !== new URL(c.origin).origin || new URL(c.redirectUri).pathname !== '/mcu/oauth/callback') throw new Error('OAUTH_REDIRECT_URI must match HTTPS /mcu/oauth/callback');
  if (c.host !== '127.0.0.1') throw new Error('Bind to loopback behind existing HTTPS proxy');
  if (!Number.isFinite(c.ttl) || !Number.isInteger(c.port) || c.port < 1024 || c.port > 65535) throw new Error('Invalid numeric configuration');
  return c;
}
