import { mkdir, readFile, open, rename, chmod } from 'node:fs/promises';
import { join } from 'node:path';
import { randomBytes, createCipheriv, createDecipheriv } from 'node:crypto';

export class Store {
  constructor(dir, key) {
    this.dir = dir;
    this.key = Buffer.from(key || '', 'base64');
    if (this.key.length !== 32) throw new Error('MCU_ENCRYPTION_KEY must be 32 bytes, base64 encoded');
  }
  path(name) {
    if (!/^[a-z0-9.-]+$/.test(name)) throw new Error('Invalid storage key');
    return join(this.dir, name + '.json');
  }
  async read(name) {
    try { return JSON.parse(await readFile(this.path(name), 'utf8')); }
    catch (e) { if (e.code === 'ENOENT') return null; throw e; }
  }
  async write(name, value) {
    await mkdir(this.dir, { recursive: true, mode: 0o700 });
    await chmod(this.dir, 0o700);
    const target = this.path(name);
    const temp = target + '.' + randomBytes(8).toString('hex') + '.tmp';
    const f = await open(temp, 'wx', 0o600);
    try { await f.writeFile(JSON.stringify(value, null, 2)); await f.sync(); }
    finally { await f.close(); }
    await rename(temp, target);
    const d = await open(this.dir, 'r');
    try { await d.sync(); } finally { await d.close(); }
  }
  async writeSecret(name, value) {
    const iv = randomBytes(12);
    const c = createCipheriv('aes-256-gcm', this.key, iv);
    c.setAAD(Buffer.from(name));
    const ciphertext = Buffer.concat([c.update(JSON.stringify(value)), c.final()]);
    await this.write(name, { v: 1, iv: iv.toString('base64'), tag: c.getAuthTag().toString('base64'), ciphertext: ciphertext.toString('base64') });
  }
  async readSecret(name) {
    const box = await this.read(name);
    if (!box) return null;
    const c = createDecipheriv('aes-256-gcm', this.key, Buffer.from(box.iv, 'base64'));
    c.setAAD(Buffer.from(name));
    c.setAuthTag(Buffer.from(box.tag, 'base64'));
    return JSON.parse(Buffer.concat([c.update(Buffer.from(box.ciphertext, 'base64')), c.final()]).toString());
  }
}
