import http from 'node:http';
import { readFile, mkdir, open, unlink } from 'node:fs/promises';
import { join } from 'node:path';
import { randomBytes, createHash, timingSafeEqual } from 'node:crypto';
import { pathToFileURL } from 'node:url';
import { config } from './config.mjs';
import { Store } from './store.mjs';
import { Trakt } from './trakt.mjs';
import { Timeline } from './timeline.mjs';
import { WatchSync, buildQueue } from './progress.mjs';

const digest = s => createHash('sha256').update(s).digest();
const equal = (a, b) => timingSafeEqual(digest(a || ''), digest(b || ''));
export function createService(c, dependencies = {}) {
  const store = dependencies.store || new Store(c.dir, c.encryptionKey);
  const trakt = dependencies.trakt || new Trakt({ clientId: c.clientId, clientSecret: c.clientSecret, redirectUri: c.redirectUri, store });
  const timeline = dependencies.timeline || new Timeline({ store, trakt, tmdbBearer: c.tmdbBearer });
  const sync = dependencies.sync || new WatchSync(trakt, store, c.ttl);
  const sessions = new Map();
  const limits = new Map();
  function rateLimit(id, max) {
    const now = Date.now();
    const current = limits.get(id);
    const value = current && current.until > now ? current : { count: 0, until: now + 60000 };
    value.count++; limits.set(id, value);
    if (limits.size > 1000) for (const [k, v] of limits) if (v.until <= now) limits.delete(k);
    return value.count <= max;
  }
  const server = http.createServer(async (req, res) => {
    const send = (status, data, contentType = 'application/json; charset=utf-8') => {
      res.writeHead(status, { 'Content-Type': contentType, 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'no-referrer', 'Content-Security-Policy': "default-src 'none'; frame-ancestors 'none'" });
      res.end(typeof data === 'string' ? data : JSON.stringify(data));
    };
    try {
      const url = new URL(req.url, c.origin);
      const path = url.pathname;
      if (req.method === 'GET' && path === '/mcu/healthz') return send(200, { ok: true });
      if (req.method === 'GET' && path === '/mcu/widget.js') {
        const source = await readFile(new URL('../widget/mcu-watch-order.js', import.meta.url), 'utf8');
        return send(200, source, 'application/javascript; charset=utf-8');
      }
      if (req.method === 'GET' && path === '/mcu/oauth/callback') {
        const state = url.searchParams.get('state');
        const session = sessions.get(state);
        sessions.delete(state);
        if (!session || session.expires < Date.now() || !url.searchParams.get('code')) return send(400, '授权已过期或被拒绝，请重新发起。', 'text/plain; charset=utf-8');
        const token = await trakt.oauth('/oauth/token', { client_id: c.clientId, redirect_uri: c.redirectUri, grant_type: 'authorization_code', code: url.searchParams.get('code'), code_verifier: session.verifier });
        await trakt.saveToken(token);
        return send(200, 'Trakt 授权已完成。返回 Rex 刷新漫威宇宙时间线。', 'text/plain; charset=utf-8');
      }
      const bearer = req.headers.authorization?.replace(/^Bearer /, '') || '';
      const admin = path.startsWith('/mcu/admin/');
      if (!equal(bearer, admin ? c.adminKey : c.accessKey)) return send(401, { error: 'PRIVATE_API_KEY_REQUIRED' });
      if (!rateLimit(admin ? 'admin' : 'read', admin ? 10 : 30)) return send(429, { error: 'RETRY_LATER' });
      if (req.method === 'POST' && path === '/mcu/admin/oauth/start') {
        for (const [key, session] of sessions) if (session.expires < Date.now()) sessions.delete(key);
        const verifier = randomBytes(48).toString('base64url');
        const state = randomBytes(32).toString('base64url');
        sessions.set(state, { verifier, expires: Date.now() + 600000 });
        const params = new URLSearchParams({ client_id: c.clientId, redirect_uri: c.redirectUri, response_type: 'code', state, code_challenge_method: 'S256', code_challenge: createHash('sha256').update(verifier).digest('base64url') });
        return send(200, { authorizationUrl: 'https://auth.trakt.tv/oauth/authorize?' + params });
      }
      if (req.method === 'GET' && path === '/mcu/admin/status') {
        const tokens = await store.readSecret('tokens');
        return send(200, { authorized: Boolean(tokens), timeline: await store.read('update-status'), watchedSyncedAt: (await store.read('watched'))?.syncedAt || null });
      }
      if (req.method === 'POST' && path === '/mcu/admin/update') {
        const result = await timeline.update();
        return send(200, { version: result.version, count: result.entries.length });
      }
      if (req.method === 'GET' && path === '/mcu/v1/queue') {
        const catalog = await timeline.load();
        if (catalog.metadataStatus !== 'resolved') return send(503, { error: 'TIMELINE_SETUP_REQUIRED', message: '标准清单已建立，尚需联网核实媒体 ID 和分集元数据。' });
        const snapshot = await sync.load(url.searchParams.get('refresh') === '1');
        const updateStatus = await store.read('update-status');
        const warning = [snapshot.warning, catalog.sourceWarning, updateStatus?.success === false ? '时间线更新失败，使用上次数据' : '', catalog.pendingReview ? catalog.pendingReview + '部新作品待核实' : '', Date.now() - Date.parse(catalog.updatedAt) > 172800000 ? '时间线已超过48小时未更新' : ''].filter(Boolean).join('；');
        const items = buildQueue(catalog, { ...snapshot, warning });
        return send(200, { items, syncedAt: snapshot.syncedAt, timelineVersion: catalog.version, timelineUpdatedAt: catalog.updatedAt, warning: warning || null, emptyMessage: items.length ? null : warning ? '当前已知已发行内容全部完成；' + warning : '当前已核实、已发行的 MCU 时间线已全部完成。' });
      }
      send(404, { error: 'NOT_FOUND' });
    } catch (e) {
      // Deliberately log no URL, request headers, provider bodies, tokens or stack.
      const code = String(e.code || e.message || 'SERVICE_ERROR').split(':')[0];
      const allowed = /^[A-Z0-9_]+$/.test(code) ? code : 'SERVICE_ERROR';
      send(503, { error: allowed, message: '暂时无法刷新；已保存的记录保留。需要时重新授权 Trakt。' });
    }
  });
  return { server, timeline, sync, store };
}

export async function start(c = config()) {
  await mkdir(c.dir, { recursive: true, mode: 0o700 });
  const lockPath = join(c.dir, 'service.lock');
  // Single process owns refresh-token rotation and updates. Do not run CLI token
  // writers concurrently. systemd RuntimeDirectory removes stale locks on restart.
  let lock;
  try { lock = await open(lockPath, 'wx', 0o600); }
  catch (e) {
    if (e.code !== 'EEXIST') throw e;
    const pid = Number(await readFile(lockPath, 'utf8'));
    try { process.kill(pid, 0); throw new Error('SERVICE_ALREADY_RUNNING'); }
    catch (problem) { if (problem.code !== 'ESRCH') throw problem; }
    await unlink(lockPath); lock = await open(lockPath, 'wx', 0o600);
  }
  await lock.writeFile(String(process.pid));
  const service = createService(c);
  await new Promise((resolve, reject) => { service.server.once('error', reject); service.server.listen(c.port, c.host, resolve); });
  const periodic = setInterval(async () => {
    try {
      const status = await service.store.read('update-status');
      const due = !status || (status.success ? Date.now() - Date.parse(status.checkedAt) >= 86400000 : Date.now() >= status.retryAt);
      if (due) await service.timeline.update();
    } catch { /* Keep serving the last good snapshot. */ }
  }, 60000);
  periodic.unref();
  service.timeline.update().catch(() => {});
  async function stop() { clearInterval(periodic); service.server.close(); await lock.close(); await unlink(lockPath).catch(() => {}); }
  process.once('SIGTERM', stop); process.once('SIGINT', stop);
  console.log('MCU service listening on loopback; no personal request logging');
  return service;
}
if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) start().catch(() => { console.error('Service startup failed; check configuration and service lock'); process.exitCode = 1; });
