export class RemoteError extends Error {
  constructor(code, retryAt = null) { super(code); this.code = code; this.retryAt = retryAt; }
}

// All Trakt personal-data writes are forbidden; only OAuth token POSTs are implemented.
export class Trakt {
  constructor({ clientId, clientSecret, redirectUri, store, fetchImpl = fetch, now = Date.now }) {
    Object.assign(this, { clientId, clientSecret, redirectUri, store, fetchImpl, now });
    this.refreshing = null;
    this.blockedUntil = 0;
  }
  async raw(origin, path, { method = 'GET', body, accessToken } = {}) {
    if (this.now() < this.blockedUntil) throw new RemoteError('TRAKT_RATE_LIMIT', this.blockedUntil);
    const headers = { 'Content-Type': 'application/json', 'trakt-api-version': '2', 'trakt-api-key': this.clientId };
    if (accessToken) headers.Authorization = 'Bearer ' + accessToken;
    let response;
    try {
      response = await this.fetchImpl(origin + path, { method, headers, body: body === undefined ? undefined : JSON.stringify(body), signal: AbortSignal.timeout(18000), redirect: 'error' });
    } catch { throw new RemoteError('TRAKT_NETWORK'); }
    if (response.status === 429) {
      const retry = response.headers.get('retry-after');
      const seconds = Number(retry);
      this.blockedUntil = Number.isFinite(seconds) && seconds > 0 ? this.now() + seconds * 1000 : Math.max(this.now() + 60000, Date.parse(retry) || 0);
      throw new RemoteError('TRAKT_RATE_LIMIT', this.blockedUntil);
    }
    let data = null;
    const text = await response.text();
    if (text) { try { data = JSON.parse(text); } catch { throw new RemoteError('TRAKT_INVALID_RESPONSE'); } }
    if (!response.ok) throw new RemoteError(response.status === 401 ? 'TRAKT_UNAUTHORIZED' : 'TRAKT_HTTP_' + response.status);
    return { data, headers: response.headers, status: response.status };
  }
  async oauth(path, body) {
    if (!['/oauth/token', '/oauth/device/code', '/oauth/device/token'].includes(path)) throw new Error('OAuth endpoint not allowed');
    return (await this.raw('https://auth.trakt.tv', path, { method: 'POST', body })).data;
  }
  async saveToken(token) {
    if (!token?.access_token || !token.refresh_token || !Number.isFinite(token.expires_in) || !Number.isFinite(token.created_at)) throw new RemoteError('TRAKT_INVALID_TOKEN');
    await this.store.writeSecret('tokens', token);
    return token;
  }
  async refresh(staleAccessToken) {
    if (this.refreshing) return this.refreshing;
    this.refreshing = (async () => {
      const old = await this.store.readSecret('tokens');
      if (!old) throw new RemoteError('TRAKT_AUTH_REQUIRED');
      if (staleAccessToken && old.access_token !== staleAccessToken) return old;
      const body = { refresh_token: old.refresh_token, client_id: this.clientId, grant_type: 'refresh_token', redirect_uri: this.redirectUri };
      if (this.clientSecret) body.client_secret = this.clientSecret;
      try { return await this.saveToken(await this.oauth('/oauth/token', body)); }
      catch (e) {
        // Never discard a valid watched snapshot on OAuth failure.
        if (['TRAKT_HTTP_400', 'TRAKT_UNAUTHORIZED'].includes(e.code)) throw new RemoteError('TRAKT_REAUTHORIZE');
        throw e;
      }
    })().finally(() => { this.refreshing = null; });
    return this.refreshing;
  }
  async get(path, query = {}, authenticated = true) {
    if (!path.startsWith('/') || path.startsWith('//')) throw new Error('Invalid Trakt path');
    let token = authenticated ? await this.store.readSecret('tokens') : null;
    if (authenticated && !token) throw new RemoteError('TRAKT_AUTH_REQUIRED');
    if (token && (token.created_at + token.expires_in) * 1000 < this.now() + 60000) token = await this.refresh(token.access_token);
    const suffix = new URLSearchParams(query).toString();
    const url = path + (suffix ? '?' + suffix : '');
    try { return await this.raw('https://api.trakt.tv', url, { accessToken: token?.access_token }); }
    catch (e) {
      if (e.code !== 'TRAKT_UNAUTHORIZED' || !authenticated) throw e;
      token = await this.refresh(token.access_token);
      return this.raw('https://api.trakt.tv', url, { accessToken: token.access_token });
    }
  }
  async pages(path, query = {}, authenticated = true) {
    const all = [];
    const seenPages = new Set();
    for (let page = 1; page <= 10000; page++) {
      const response = await this.get(path, { ...query, page: String(page), limit: '100' }, authenticated);
      if (!Array.isArray(response.data)) throw new RemoteError('TRAKT_INVALID_RESPONSE');
      if (!response.data.length) return all;
      const signature = JSON.stringify(response.data);
      if (seenPages.has(signature)) throw new RemoteError('TRAKT_REPEATED_PAGE');
      seenPages.add(signature);
      all.push(...response.data);
      const count = Number(response.headers.get('x-pagination-page-count'));
      if (count > 0 && page >= count) return all;
      // A short page may be the server's applied limit, not the requested limit.
      // Without a reliable page count, continue until an empty array.
    }
    throw new RemoteError('TRAKT_TOO_MANY_PAGES');
  }
}
