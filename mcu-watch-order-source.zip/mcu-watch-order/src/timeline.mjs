import { readFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';

export const SOURCE = 'https://www.marvel.com/articles/movies/mcu-timeline-order-disney-plus';
export function normalize(value) {
  return value.normalize('NFKD').toLowerCase()
    .replace(/^marvel(?: studios)?\s+one[ -]?shot\s*:?\s*/, '')
    .replace(/^marvel['’]s\s+/, '')
    .replace(/[^a-z0-9]/g, '');
}
const text = html => html.replace(/<[^>]+>/g, '').replace(/&nbsp;|&#160;/g, ' ').replace(/&amp;/g, '&').replace(/&#39;|&apos;/g, "'").replace(/&quot;/g, '"').replace(/&#(\d+);/g, (_, n) => String.fromCodePoint(Number(n))).replace(/\s+/g, ' ').trim();
export function parseOfficial(html) {
  // Deliberately narrow parser: a redesign is a review event, never an empty catalog.
  const section = html.match(/<h[1-6][^>]*>\s*MCU Complete Timeline\s*<\/h[1-6]>\s*<ul[^>]*>([\s\S]*?)<\/ul>/i);
  if (!section) throw new Error('OFFICIAL_FORMAT_CHANGED');
  const labels = [...section[1].matchAll(/<li[^>]*>([\s\S]*?)<\/li>/gi)].map(m => text(m[1]));
  if (labels.length < 50 || new Set(labels.map(normalize)).size !== labels.length) throw new Error('OFFICIAL_LIST_INVALID');
  return labels;
}

export class Timeline {
  constructor({ store, trakt, tmdbBearer, fetchImpl = fetch, now = Date.now, seedLoader }) {
    Object.assign(this, { store, trakt, tmdbBearer, fetchImpl, now });
    this.seedLoader = seedLoader || (async () => JSON.parse(await readFile(new URL('../data/timeline.seed.json', import.meta.url), 'utf8')));
    this.updating = null;
  }
  async load() { return await this.store.read('timeline') || await this.seedLoader(); }
  async identify(entry) {
    const kind = entry.mediaType === 'tv' ? 'show' : 'movie';
    if (entry.traktId && entry.tmdbId) return entry;
    const names = [entry.originalTitle, ...(entry.searchAliases || [])];
    const found = new Map();
    for (const query of names) {
      const results = await this.trakt.pages('/search/' + kind + '/exact', { query }, false);
      for (const result of results) {
        const media = result[kind];
        if (!media?.ids?.trakt || !media.ids.tmdb) continue;
        if (!names.some(n => normalize(n) === normalize(media.title))) continue;
        if (entry.searchYear && media.year !== entry.searchYear) continue;
        found.set(media.ids.trakt, media);
      }
      if (found.size) break;
    }
    if (found.size !== 1) throw new Error('IDENTITY_REVIEW_REQUIRED:' + entry.stableId);
    const media = [...found.values()][0];
    return { ...entry, tmdbId: media.ids.tmdb, traktId: media.ids.trakt, imdbId: media.ids.imdb || null, identitySource: 'Trakt exact title + media type + year', identityVerifiedAt: new Date(this.now()).toISOString() };
  }
  async enrich(entry) {
    entry = await this.identify(entry);
    const route = (entry.mediaType === 'tv' ? '/shows/' : '/movies/') + entry.traktId;
    const media = (await this.trakt.get(route, { extended: 'full' }, false)).data;
    if (media.ids?.trakt !== entry.traktId || media.ids?.tmdb !== entry.tmdbId) throw new Error('MEDIA_ID_CHANGED');
    const result = { ...entry, overview: media.overview || '', metadataVerifiedAt: new Date(this.now()).toISOString() };
    if (entry.mediaType === 'movie') {
      result.releaseDate = media.released || null;
      result.availabilityStatus = media.released && Date.parse(media.released) <= this.now() ? 'released' : 'announced';
    } else {
      const episodes = (await this.trakt.get(route + '/seasons/' + entry.season, { extended: 'full' }, false)).data;
      const seasons = (await this.trakt.get(route + '/seasons', { extended: 'full' }, false)).data;
      if (!Array.isArray(episodes) || !Array.isArray(seasons)) throw new Error('EPISODE_METADATA_INVALID');
      const selected = episodes.filter(e => e.season === entry.season && e.number > 0 && (!entry.episodeRange || (e.number >= entry.episodeRange[0] && e.number <= entry.episodeRange[1]))).sort((a, b) => a.number - b.number);
      if (selected.some(e => !e.ids?.trakt)) throw new Error('EPISODE_METADATA_INCOMPLETE:' + entry.stableId);
      result.episodes = selected.map(e => ({ season: e.season, number: e.number, firstAired: e.first_aired, traktId: e.ids.trakt }));
      const total = entry.episodeRange ? entry.episodeRange[1] - entry.episodeRange[0] + 1 : seasons.find(s => s.number === entry.season)?.episode_count;
      const aired = selected.filter(e => e.first_aired && Date.parse(e.first_aired) <= this.now());
      result.segmentComplete = Number.isInteger(total) && total > 0 && total === selected.length && aired.length === total;
      result.releaseDate = aired[0]?.first_aired || selected[0]?.first_aired || null;
      result.availabilityStatus = aired.length ? 'available' : 'announced';
    }
    if (this.tmdbBearer) {
      try {
        const response = await this.fetchImpl('https://api.themoviedb.org/3/' + entry.mediaType + '/' + entry.tmdbId + '?language=zh-CN', { headers: { Authorization: 'Bearer ' + this.tmdbBearer }, signal: AbortSignal.timeout(15000), redirect: 'error' });
        if (response.ok) {
          const tmdb = await response.json();
          if (tmdb.id !== entry.tmdbId) throw new Error('TMDB_ID_CHANGED');
          result.title = tmdb.title || tmdb.name || result.title;
          result.overview = tmdb.overview || result.overview;
          result.posterPath = tmdb.poster_path;
          result.backdropPath = tmdb.backdrop_path;
        }
      } catch { result.metadataNotice = 'TMDB 元数据刷新失败，保留 Trakt 元数据'; }
    }
    return result;
  }
  async checkOfficial(old) {
    const response = await this.fetchImpl(SOURCE, { signal: AbortSignal.timeout(20000), redirect: 'error', headers: { 'User-Agent': 'Personal-MCU-Timeline/0.1' } });
    if (!response.ok) throw new Error('OFFICIAL_HTTP_' + response.status);
    const html = await response.text();
    if (html.length > 5_000_000) throw new Error('OFFICIAL_RESPONSE_TOO_LARGE');
    const labels = parseOfficial(html);
    if (labels.length < old.entries.length * 0.8) throw new Error('OFFICIAL_TOO_MANY_REMOVALS');
    const known = new Map(old.entries.map(e => [normalize(e.officialLabel), e]));
    const entries = [], proposals = [];
    for (const [i, label] of labels.entries()) {
      let entry = known.get(normalize(label));
      if (!entry) {
        const seasonMatch = label.match(/\s+S(\d+)$/i);
        const title = label.replace(/\s+S\d+$/i, '').trim();
        const previousSeason = old.entries.find(e => normalize(e.originalTitle) === normalize(title) && e.mediaType === 'tv');
        if (previousSeason && seasonMatch) {
          entry = { ...previousSeason, stableId: previousSeason.stableId.replace(/-s\d+$/, '-s' + seasonMatch[1]), season: Number(seasonMatch[1]), officialLabel: label, episodes: [], segmentComplete: false };
        } else {
          const candidates = [];
          for (const kind of ['movie', 'show']) {
            const results = await this.trakt.pages('/search/' + kind + '/exact', { query: title }, false);
            for (const row of results) {
              const media = row[kind];
              if (media?.ids?.trakt && media.ids.tmdb && normalize(media.title) === normalize(title)) candidates.push({ kind, media });
            }
          }
          const unique = [...new Map(candidates.map(c => [c.kind + ':' + c.media.ids.trakt, c])).values()];
          if (unique.length === 1) {
            const { kind, media } = unique[0];
            let season = seasonMatch ? Number(seasonMatch[1]) : null;
            if (kind === 'show' && !season) {
              const seasons = (await this.trakt.get('/shows/' + media.ids.trakt + '/seasons', { extended: 'full' }, false)).data;
              const regular = Array.isArray(seasons) ? seasons.filter(s => s.number > 0) : [];
              if (regular.length === 1 && regular[0].number === 1) season = 1;
            }
            if (kind === 'movie' || season) entry = {
              stableId: 'mcu-trakt-' + kind + '-' + media.ids.trakt + (season ? '-s' + season : ''),
              title, originalTitle: title, officialLabel: label, mediaType: kind === 'show' ? 'tv' : 'movie',
              tmdbId: media.ids.tmdb, traktId: media.ids.trakt, imdbId: media.ids.imdb || null,
              searchYear: media.year, season, episodeRange: null, universe: 'official-unclassified',
              availabilityStatus: 'pending_metadata', releaseDate: null,
              identitySource: 'Unique Trakt exact match; membership/order verified in Marvel complete timeline'
            };
          }
          if (!entry) {
            proposals.push({ label, officialPosition: i + 1, source: SOURCE, reason: 'NEW_TITLE_IDENTITY_OR_SEASON_REVIEW' });
            continue;
          }
        }
      }
      entries.push({ ...entry, timelineOrder: (i + 1) * 10, timelineEra: '官方完整时间线第' + (i + 1) + '位' + (entry.universe === 'multiverse' ? '（推荐观影位置）' : '（主体故事顺序）'), lastVerifiedAt: new Date(this.now()).toISOString(), chronologySource: [{ url: SOURCE, basis: 'rendered-list-label', position: i + 1 }] });
    }
    if (proposals.length) await this.store.write('timeline-proposals', { checkedAt: new Date(this.now()).toISOString(), proposals });
    // Avoid silently losing a formerly verified title if official text changes spelling.
    const missing = old.entries.filter(e => !entries.some(n => n.stableId === e.stableId));
    if (missing.length) throw new Error('OFFICIAL_REMOVAL_REVIEW_REQUIRED');
    return { ...old, entries, sourceWarning: undefined, pendingReview: proposals.length, officialCheckedAt: new Date(this.now()).toISOString() };
  }
  async update({ maxNewEntries = Infinity, deadline = Infinity, verifyOfficial = true, tolerateMissing = false, current } = {}) {
    if (this.updating) return this.updating;
    this.updating = (async () => {
      const old = current || await this.load();
      let candidate = old;
      if (verifyOfficial) {
        const pending = Number.isFinite(maxNewEntries) ? await this.store.read('pending-catalog') : null;
        if (pending?.version === old.version && this.now() < pending.expiresAt) {
          candidate = pending.candidate;
        } else {
          try { candidate = await this.checkOfficial(old); }
          catch (e) { candidate = { ...old, sourceWarning: e.message.split(':')[0] }; }
          if (Number.isFinite(maxNewEntries)) await this.store.write('pending-catalog', { version: old.version, expiresAt: this.now() + 3600000, candidate });
        }
      }
      const entries = [];
      try {
        const metadata = await this.store.read('metadata-cache') || {};
        let fetched = 0;
        for (const e of candidate.entries) {
          const cached = metadata[e.stableId];
          let resolved;
          if (cached && cached.originalTitle === e.originalTitle && cached.mediaType === e.mediaType &&
              cached.season === e.season && String(cached.episodeRange) === String(e.episodeRange) &&
              this.now() - Date.parse(cached.metadataVerifiedAt) < 23 * 3600000) {
            // Keep fresh chronology fields from the official list, but reuse expensive
            // IDs/episodes/artwork independently of the watched-state cache.
            resolved = { ...e, ...cached, timelineOrder: e.timelineOrder, timelineEra: e.timelineEra, chronologySource: e.chronologySource, lastVerifiedAt: e.lastVerifiedAt };
          } else {
            if (fetched >= maxNewEntries || (fetched > 0 && this.now() >= deadline)) {
              return { ...candidate, entries, metadataStatus: 'initializing', totalEntries: candidate.entries.length };
            }
            try { resolved = await this.enrich(e); }
            catch (error) {
              if (!tolerateMissing || !/^(IDENTITY_REVIEW_REQUIRED:|EPISODE_METADATA_INCOMPLETE:)/.test(error.message)) throw error;
              resolved = { ...e, availabilityStatus: 'pending_metadata', metadataVerifiedAt: new Date(this.now()).toISOString() };
            }
            fetched++;
            metadata[e.stableId] = resolved;
            // Checkpoint initialization so a rate limit on item 80 doesn't cause
            // the next attempt to download items 1–79 again.
            await this.store.write('metadata-cache', metadata);
          }
          entries.push(resolved);
        }
        const revision = createHash('sha256').update(JSON.stringify(entries)).digest('hex').slice(0, 12);
        const next = { ...candidate, entries, metadataStatus: 'resolved', version: new Date(this.now()).toISOString().slice(0, 10) + '.' + revision, updatedAt: new Date(this.now()).toISOString() };
        await this.store.write('timeline', next);
        await this.store.write('update-status', { success: true, checkedAt: next.updatedAt, sourceWarning: next.sourceWarning, pendingReview: next.pendingReview || 0 });
        return next;
      } catch (e) {
        await this.store.write('update-status', { success: false, checkedAt: new Date(this.now()).toISOString(), retryAt: Math.max(this.now() + 300000, e.retryAt || 0), error: e.message.split(':')[0] });
        throw e;
      }
    })().finally(() => { this.updating = null; });
    return this.updating;
  }
}
