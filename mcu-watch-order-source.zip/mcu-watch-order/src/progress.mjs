function idsOf(entry) { return entry?.ids || {}; }
export function matches(a, b) {
  const left = a.ids || { tmdb: a.tmdbId, imdb: a.imdbId, trakt: a.traktId };
  const right = idsOf(b);
  return ['trakt', 'tmdb', 'imdb'].some(k => left[k] != null && right[k] != null && String(left[k]) === String(right[k]));
}
export function nextEpisode(entry, watched, now = Date.now()) {
  const show = watched.find(w => matches(entry, w.show));
  const done = new Set((show?.seasons || []).flatMap(s => s.episodes.filter(e => e.plays > 0 && (!show.reset_at || Date.parse(e.last_watched_at) >= Date.parse(show.reset_at))).map(e => s.number + ':' + e.number)));
  const episodes = (entry.episodes || []).filter(e => e.firstAired && Date.parse(e.firstAired) <= now);
  const remaining = episodes.filter(e => !done.has(e.season + ':' + e.number));
  return { next: remaining[0] || null, remaining: remaining.length, complete: entry.segmentComplete === true && episodes.length > 0 && remaining.length === 0, watched: episodes.length - remaining.length };
}
export function buildQueue(timeline, snapshot, now = Date.now()) {
  if (!snapshot?.movies || !snapshot?.shows) throw new Error('WATCH_STATE_UNAVAILABLE');
  const items = [];
  for (const entry of [...timeline.entries].sort((a, b) => a.timelineOrder - b.timelineOrder)) {
    if (!['available', 'released'].includes(entry.availabilityStatus) || !entry.releaseDate || Date.parse(entry.releaseDate) > now) continue;
    if (!entry.tmdbId) continue;
    let progress = null;
    if (entry.mediaType === 'movie') {
      if (snapshot.movies.some(w => w.plays > 0 && matches(entry, w.movie))) continue;
    } else {
      progress = nextEpisode(entry, snapshot.shows, now);
      if (progress.complete) continue;
      if (!progress.next) continue; // released episodes all watched, future episodes cannot lead the queue
    }
    const paused = (snapshot.playback || []).find(p => p.progress > 0 && p.progress < 100 && (entry.mediaType === 'movie' ? p.type === 'movie' && matches(entry, p.movie) : p.type === 'episode' && matches(entry, p.show) && p.episode?.season === progress.next.season && p.episode?.number === progress.next.number));
    const live = snapshot.watching && Date.parse(snapshot.watching.expires_at) > now && Date.parse(snapshot.watching.started_at) <= now && (entry.mediaType === 'movie' ? snapshot.watching.type === 'movie' && matches(entry, snapshot.watching.movie) : snapshot.watching.type === 'episode' && matches(entry, snapshot.watching.show) && snapshot.watching.episode?.season === progress.next.season && snapshot.watching.episode?.number === progress.next.number);
    const status = live ? '正在观看' : paused ? '继续观看 ' + Math.round(paused.progress) + '%' : progress?.watched ? '部分观看' : '未观看';
    const next = progress?.next ? '下一集：S' + String(progress.next.season).padStart(2, '0') + 'E' + String(progress.next.number).padStart(2, '0') : '';
    const segment = entry.mediaType === 'tv' ? '第' + entry.season + '季' : '';
    const notices = snapshot.warning ? '同步提示：' + snapshot.warning + '；上次成功：' + snapshot.syncedAt : '';
    items.push({
      id: entry.mediaType + '.' + entry.tmdbId, type: 'tmdb', mediaType: entry.mediaType,
      title: [entry.title || entry.originalTitle, segment, next || status].filter(Boolean).join(' · '),
      releaseDate: entry.releaseDate, posterPath: entry.posterPath || undefined, backdropPath: entry.backdropPath || undefined,
      description: [entry.originalTitle, entry.timelineEra, entry.universe === 'multiverse' ? '多元宇宙分支 · 官方推荐观影位置' : entry.universe === 'official-unclassified' ? '官方已收录；宇宙归属待核实' : '', status, next, entry.overview, 'Trakt 同步：' + snapshot.syncedAt, notices].filter(Boolean).join('\n'),
      ...(progress?.next ? { season: progress.next.season, episode: progress.next.number } : {})
    });
  }
  return items;
}

export class WatchSync {
  constructor(trakt, store, ttl = 600000, now = Date.now) { Object.assign(this, { trakt, store, ttl, now }); this.pending = null; this.nextAttempt = 0; }
  async load(force = false, cacheOnly = false) {
    const old = await this.store.read('watched');
    if (old && (cacheOnly || (!force && this.now() - Date.parse(old.syncedAt) < this.ttl))) return old;
    if (this.pending) return this.pending;
    if (this.now() < this.nextAttempt) {
      if (old) return { ...old, warning: '观看状态暂不可刷新，使用缓存' };
      throw new Error('WATCH_SYNC_RETRY_LATER');
    }
    this.pending = (async () => {
      try {
        let activities;
        try { activities = (await this.trakt.get('/sync/last_activities')).data; }
        catch (error) {
          if (error.code !== 'TRAKT_HTTP_404') throw error;
        }
        const unchanged = (kind, field) => Boolean(
          activities?.[kind]?.[field] && old?.activities?.[kind]?.[field] === activities[kind][field]
        );
        const [movies, shows] = await Promise.all([
          unchanged('movies', 'watched_at') ? old.movies : this.trakt.get('/sync/watched/movies').then(r => r.data),
          unchanged('episodes', 'watched_at') ? old.shows : this.trakt.get('/sync/watched/shows', { extended: 'progress' }).then(r => r.data)
        ]);
        if (!Array.isArray(movies) || !Array.isArray(shows)) throw new Error('TRAKT_INVALID_RESPONSE');
        if (shows.some(s => !Array.isArray(s?.seasons) || s.seasons.some(season => !Array.isArray(season?.episodes)))) {
          throw new Error('TRAKT_MISSING_EPISODES');
        }
        let playback = old?.playback || [], watching = null, playbackWarning;
        try {
          if (!(unchanged('movies', 'paused_at') && unchanged('episodes', 'paused_at')) || old?.warning) {
            playback = await this.trakt.pages('/sync/playback');
          }
          watching = (await this.trakt.get('/users/me/watching')).data;
        } catch { playbackWarning = '播放进度暂不可用；已观看记录已同步'; }
        const next = { movies, shows, playback, watching, activities, syncedAt: new Date(this.now()).toISOString(), warning: playbackWarning };
        await this.store.write('watched', next);
        this.nextAttempt = 0;
        return next;
      } catch (e) {
        this.nextAttempt = Math.max(this.now() + 60000, e.retryAt || 0);
        if (!old) throw e;
        return { ...old, warning: (e.code || e.message || 'WATCH_SYNC_FAILED').split(':')[0] + '，使用最近有效记录' };
      }
    })().finally(() => { this.pending = null; });
    return this.pending;
  }
}
