import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import { readFile } from 'node:fs/promises';
import { createService } from '../src/server.mjs';
import { config } from '../src/config.mjs';

const source = await readFile(new URL('../widget/mcu-watch-order.js', import.meta.url), 'utf8');
const params = { endpoint: 'https://fixture.example/mcu', accessKey: 'test-only-'.repeat(5), page: '1' };
const payload = () => ({ syncedAt: '2026-11-08T00:00:00Z', items: [{ id: 'movie.1', type: 'tmdb', mediaType: 'movie', title: '测试 · 未观看', description: 'Original title\n同步时间' }] });
function widget(http) {
  const storage = new Map();
  const context = vm.createContext({ Widget: { http, storage: { get: async k => storage.get(k), set: async (k, v) => storage.set(k, v) } } });
  vm.runInContext(source, context);
  return { context, storage };
}
test('widget sends read key only as Authorization header and leaves media identity intact', async () => {
  const { context } = widget({ get: async (url, options) => {
    assert.equal(url, params.endpoint + '/v1/queue'); assert(!url.includes(params.accessKey));
    assert.equal(options.headers.Authorization, 'Bearer ' + params.accessKey);
    return { data: payload(), statusCode: 200 };
  } });
  const result = await context.loadMcuTimeline(params);
  assert.equal(result[0].id, 'movie.1'); assert.equal(result[0].mediaType, 'movie');
  assert.equal(context.WidgetMetadata.modules[0].cacheDuration, 0);
});
test('G: widget offline cache is marked stale and never creates an unwatched account', async () => {
  let offline = false;
  const { context } = widget({ get: async () => { if (offline) throw new Error('offline'); return { data: payload() }; } });
  await context.loadMcuTimeline(params); offline = true;
  const result = await context.loadMcuTimeline(params);
  assert.match(result[0].title, /同步提示/); assert.match(result[0].description, /2026-11-08/);
  await assert.rejects(context.loadMcuTimeline({ ...params, accessKey: 'other-account'.repeat(4) }), /尚无有效缓存/);
});
test('revoked read key never falls back to private cached data', async () => {
  let revoked = false;
  const { context } = widget({ get: async () => revoked ? { statusCode: 401, data: {} } : { data: payload() } });
  await context.loadMcuTimeline(params); revoked = true;
  await assert.rejects(context.loadMcuTimeline(params), /密钥无效或已撤销/);
});
test('setup and OAuth errors are not disguised as a working stale list', async () => {
  let error;
  const { context } = widget({ get: async () => ({ data: error ? { error } : payload(), statusCode: error ? 503 : 200 }) });
  await context.loadMcuTimeline(params); error = 'TIMELINE_SETUP_REQUIRED';
  await assert.rejects(context.loadMcuTimeline(params), /尚未完成/);
  error = 'TRAKT_REAUTHORIZE'; await assert.rejects(context.loadMcuTimeline(params), /重新授权/);
});
test('empty state uses explicit completion message, no fake media card', async () => {
  const { context } = widget({ get: async () => ({ data: { items: [], syncedAt: '2026-11-08', emptyMessage: '当前全部完成' } }) });
  await assert.rejects(context.loadMcuTimeline(params), /当前全部完成/);
});
test('pagination never requests active force-sync more than page one', async () => {
  const calls = [];
  const { context } = widget({ get: async (_, options) => { calls.push(options.params.refresh); return { data: payload() }; } });
  await context.loadMcuTimeline({ ...params, refresh: 'force' });
  assert.equal((await context.loadMcuTimeline({ ...params, page: '2', refresh: 'force' })).length, 0);
  assert.deepEqual(calls, ['1', '0']);
});

const c = { accessKey: 'read-key'.repeat(8), adminKey: 'admin-key'.repeat(8), origin: 'https://fixture.example', redirectUri: 'https://fixture.example/mcu/oauth/callback' };
function service(options = {}) {
  return createService(c, { store: { read: async () => null, readSecret: async () => null }, timeline: { load: async () => ({ metadataStatus: 'requires-live-resolution' }) }, trakt: {}, sync: {}, ...options });
}
// Test the actual HTTP request handler without opening a socket. This is not
// a deployed HTTPS, OAuth-provider or Rex-client end-to-end test.
function request(server, path, method = 'GET', key) {
  return new Promise(resolve => {
    const res = { writeHead: (status, headers) => Object.assign(res, { status, headers }), end: body => resolve({ status: res.status, headers: res.headers, body }) };
    server.emit('request', { url: path, method, headers: key ? { authorization: 'Bearer ' + key } : {} }, res);
  });
}
test('API denies unauthenticated read/admin and does not let read key start OAuth', async () => {
  const { server } = service();
  assert.equal((await request(server, '/mcu/v1/queue')).status, 401);
  assert.equal((await request(server, '/mcu/admin/oauth/start', 'POST', c.accessKey)).status, 401);
});
test('API health and public widget expose no secret configuration', async () => {
  const { server } = service();
  assert.equal((await request(server, '/mcu/healthz')).status, 200);
  const result = await request(server, '/mcu/widget.js');
  assert.equal(result.status, 200); assert(!result.body.includes(c.adminKey)); assert(!result.body.includes(c.accessKey));
  assert.equal(result.headers['Cache-Control'], 'no-store');
});
test('API refuses queue until real ID/episode metadata resolution', async () => {
  const { server } = service();
  const result = await request(server, '/mcu/v1/queue', 'GET', c.accessKey);
  assert.equal(result.status, 503); assert.match(result.body, /TIMELINE_SETUP_REQUIRED/);
});
test('PKCE callback checks state, is single use, and uses saved verifier in exchange', async () => {
  let exchanges = 0, saved = 0;
  const { server } = service({ trakt: { oauth: async (path, body) => {
    assert.equal(path, '/oauth/token'); assert(body.code_verifier.length >= 43); assert.equal(body.code, 'fixture-code'); assert(!body.client_secret);
    exchanges++; return { fixture: true };
  }, saveToken: async () => { saved++; } } });
  const invalid = await request(server, '/mcu/oauth/callback?state=invalid&code=fixture'); assert.equal(invalid.status, 400);
  const start = JSON.parse((await request(server, '/mcu/admin/oauth/start', 'POST', c.adminKey)).body);
  const url = new URL(start.authorizationUrl); assert.equal(url.origin, 'https://auth.trakt.tv'); assert.equal(url.searchParams.get('code_challenge_method'), 'S256');
  const callback = '/mcu/oauth/callback?state=' + url.searchParams.get('state') + '&code=fixture-code';
  assert.equal((await request(server, callback)).status, 200);
  assert.equal((await request(server, callback)).status, 400); assert.equal(exchanges, 1); assert.equal(saved, 1);
});
test('config rejects public binds, mismatched callback, reused keys and weak secrets', () => {
  const env = { MCU_ACCESS_KEY: c.accessKey, MCU_ADMIN_KEY: c.adminKey, MCU_ENCRYPTION_KEY: '', TRAKT_CLIENT_ID: 'fixture', PUBLIC_ORIGIN: c.origin, OAUTH_REDIRECT_URI: c.redirectUri };
  assert.equal(config(env).host, '127.0.0.1');
  assert.throws(() => config({ ...env, HOST: '0.0.0.0' }));
  assert.throws(() => config({ ...env, MCU_ADMIN_KEY: c.accessKey }));
  assert.throws(() => config({ ...env, OAUTH_REDIRECT_URI: 'https://evil.example/mcu/oauth/callback' }));
});
