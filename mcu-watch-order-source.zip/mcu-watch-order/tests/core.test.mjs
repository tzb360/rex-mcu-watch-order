import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, readFile, stat, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { randomBytes } from 'node:crypto';
import { Store } from '../src/store.mjs';
import { Trakt } from '../src/trakt.mjs';
import { buildQueue, WatchSync } from '../src/progress.mjs';
import { Timeline, parseOfficial } from '../src/timeline.mjs';

const now = Date.parse('2026-11-08T10:00:00Z');
const movie = (id, order) => ({ stableId: 'fixture-' + id, tmdbId: id, traktId: id + 100, title: '测试电影' + id, originalTitle: 'Fixture ' + id, mediaType: 'movie', timelineOrder: order, timelineEra: '测试区段', universe: 'Earth-616', releaseDate: '2020-01-01', availabilityStatus: 'released' });
const show = (season, order) => ({ ...movie(20, order), stableId: 'fixture-tv-s' + season, mediaType: 'tv', season, segmentComplete: true, episodes: Array.from({ length: 9 }, (_, i) => ({ season, number: i + 1, firstAired: '2020-01-01' })) });
const empty = () => ({ movies: [], shows: [], playback: [], syncedAt: new Date(now).toISOString() });
const watchedShow = (season, count) => ({ show: { ids: { trakt: 120, tmdb: 20 } }, seasons: [{ number: season, episodes: Array.from({ length: count }, (_, i) => ({ number: i + 1, plays: 1 })) }] });
test('A: new account preserves mixed chronological order and excludes future/announced work', () => {
  const future = { ...movie(3, 0), releaseDate: '2099-01-01' };
  const entries = [show(1, 20), movie(1, 10), future, { ...movie(4, 1), availabilityStatus: 'announced' }];
  assert.deepEqual(buildQueue({ entries }, empty(), now).map(i => i.id), ['movie.1', 'tv.20']);
});
test('B: completed movie disappears, no mutation of watched records', () => {
  const snapshot = { ...empty(), movies: [{ movie: { ids: { tmdb: 1 } }, plays: 1 }] };
  const original = JSON.stringify(snapshot);
  assert.deepEqual(buildQueue({ entries: [movie(1, 10), movie(2, 20)] }, snapshot, now).map(i => i.id), ['movie.2']);
  assert.equal(JSON.stringify(snapshot), original);
});
test('C: five episodes watched leaves exactly S01E06 next, with partial status', () => {
  const items = buildQueue({ entries: [show(1, 20)] }, { ...empty(), shows: [watchedShow(1, 5)] }, now);
  assert.match(items[0].title, /S01E06/); assert.match(items[0].description, /部分观看/);
});
test('D: completed season hides only itself, season two stays in its own position', () => {
  const items = buildQueue({ entries: [show(2, 30), movie(1, 20), show(1, 10)] }, { ...empty(), shows: [watchedShow(1, 9)] }, now);
  assert.deepEqual(items.map(i => i.id), ['movie.1', 'tv.20']); assert.match(items[1].title, /S02E01/);
});
test('E: changed server timeline appears without widget reinstall', () => {
  const before = [movie(1, 10), movie(3, 30)];
  const after = [...before, movie(2, 20)];
  assert.deepEqual(buildQueue({ entries: before }, empty(), now).map(i => i.id), ['movie.1', 'movie.3']);
  assert.deepEqual(buildQueue({ entries: after }, empty(), now).map(i => i.id), ['movie.1', 'movie.2', 'movie.3']);
});
test('unwatched gap is respected; future episode never becomes next', () => {
  const s = show(1, 10); s.episodes[8].firstAired = '2099-01-01'; s.segmentComplete = false;
  const watched = watchedShow(1, 8); watched.seasons[0].episodes.splice(3, 1);
  assert.match(buildQueue({ entries: [s] }, { ...empty(), shows: [watched] }, now)[0].title, /S01E04/);
  assert.equal(buildQueue({ entries: [s] }, { ...empty(), shows: [watchedShow(1, 8)] }, now).length, 0);
});
test('paused playback does not outrank earliest unfinished film; expired playing event is not live', () => {
  const snap = { ...empty(), playback: [{ type: 'movie', movie: { ids: { tmdb: 2 } }, progress: 42 }], watching: { type: 'movie', movie: { ids: { tmdb: 1 } }, started_at: '2020-01-01', expires_at: '2020-01-02' } };
  const items = buildQueue({ entries: [movie(2, 20), movie(1, 10)] }, snap, now);
  assert.equal(items[0].id, 'movie.1'); assert.doesNotMatch(items[0].description, /正在观看/); assert.match(items[1].description, /继续观看 42%/);
});
test('G: failed multi-endpoint sync preserves complete cached snapshot and original sync time', async () => {
  const old = { ...empty(), syncedAt: '2020-01-01T00:00:00Z' }; let writes = 0;
  const sync = new WatchSync({ get: async path => { if (path.includes('shows')) throw new Error('NETWORK'); return { data: [] }; } }, { read: async () => old, write: async () => { writes++; } }, 1, () => now);
  const out = await sync.load(); assert.equal(out.syncedAt, old.syncedAt); assert.match(out.warning, /使用最近有效/); assert.equal(writes, 0);
});
test('no first-run cache never becomes a fake empty watched account', async () => {
  const sync = new WatchSync({ get: async () => { throw new Error('NETWORK'); } }, { read: async () => null });
  await assert.rejects(sync.load(), /NETWORK/);
});
test('missing season progress is a sync failure, never a full reset', async () => {
  const sync = new WatchSync({ get: async path => ({ data: path.includes('shows') ? [{ show: { ids: { tmdb: 20 } } }] : [] }) }, { read: async () => null });
  await assert.rejects(sync.load(), /TRAKT_MISSING_EPISODES/);
});
test('pagination follows applied server cap, even when each page is shorter than requested', async () => {
  const requests = [];
  const t = new Trakt({ clientId: 'test', store: {}, fetchImpl: async url => {
    requests.push(url); const page = Number(new URL(url).searchParams.get('page'));
    return new Response(JSON.stringify(page <= 3 ? [{ id: page }] : []));
  } });
  const rows = await t.pages('/search/movie/exact', {}, false);
  assert.equal(rows.length, 3); assert.equal(requests.length, 4);
});
test('F: concurrent expired-token requests rotate refresh token once at auth.trakt.tv', async () => {
  let token = { access_token: 'old', refresh_token: 'old-refresh', created_at: 0, expires_in: 1 };
  let refreshes = 0;
  const t = new Trakt({ clientId: 'test', redirectUri: 'https://example.com/mcu/oauth/callback', now: () => now, store: { readSecret: async () => token, writeSecret: async (_, value) => { token = value; } }, fetchImpl: async (url, options) => {
    if (url.startsWith('https://auth.trakt.tv')) {
      refreshes++; assert.equal(JSON.parse(options.body).refresh_token, 'old-refresh');
      await new Promise(resolve => setTimeout(resolve, 10));
      return Response.json({ access_token: 'new', refresh_token: 'rotated', created_at: Math.floor(now / 1000), expires_in: 604800 });
    }
    assert.equal(options.headers.Authorization, 'Bearer new'); return Response.json([]);
  } });
  await Promise.all([t.get('/sync/watched/movies'), t.get('/sync/watched/shows')]);
  assert.equal(refreshes, 1); assert.equal(token.refresh_token, 'rotated');
});
test('F: failed refresh leaves prior tokens and reports reauthorization', async () => {
  let writes = 0;
  const t = new Trakt({ clientId: 'test', store: { readSecret: async () => ({ access_token: 'old', refresh_token: 'old', created_at: 0, expires_in: 1 }), writeSecret: async () => { writes++; } }, fetchImpl: async () => Response.json({ error: 'invalid_grant', error_description: 'secret details' }, { status: 400 }) });
  await assert.rejects(t.get('/sync/watched/movies'), /TRAKT_REAUTHORIZE/); assert.equal(writes, 0);
});
test('rate limit respects Retry-After without immediate retry', async () => {
  let hits = 0;
  const t = new Trakt({ clientId: 'test', now: () => now, store: {}, fetchImpl: async () => { hits++; return new Response('', { status: 429, headers: { 'Retry-After': '60' } }); } });
  await assert.rejects(t.get('/search/movie', {}, false), /TRAKT_RATE_LIMIT/);
  await assert.rejects(t.get('/search/movie', {}, false), /TRAKT_RATE_LIMIT/); assert.equal(hits, 1);
});
test('encrypted token persistence and mode 0600; wrong key cannot decrypt', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'mcu-test-'));
  try {
    const store = new Store(dir, randomBytes(32).toString('base64'));
    await store.writeSecret('tokens', { access_token: 'SENSITIVE_TEST_TOKEN' });
    assert.doesNotMatch(await readFile(join(dir, 'tokens.json'), 'utf8'), /SENSITIVE_TEST_TOKEN/);
    assert.equal((await stat(join(dir, 'tokens.json'))).mode & 0o777, 0o600);
    assert.equal((await store.readSecret('tokens')).access_token, 'SENSITIVE_TEST_TOKEN');
    await assert.rejects(new Store(dir, randomBytes(32).toString('base64')).readSecret('tokens'));
  } finally { await rm(dir, { recursive: true }); }
});
test('official parser refuses an empty/redesigned source; supports HTML season labels', () => {
  assert.throws(() => parseOfficial('<html>blocked</html>'), /FORMAT_CHANGED/);
  const html = '<h4>MCU Complete Timeline</h4><ul>' + Array.from({ length: 60 }, (_, i) => '<li><a><em>Fixture ' + i + '</em>&nbsp;S1</a></li>').join('') + '</ul>';
  assert.equal(parseOfficial(html)[0], 'Fixture 0 S1');
});
test('seed contains 81 sourced segments, separated seasons, branch labels, no guessed external IDs', async () => {
  const seed = JSON.parse(await readFile(new URL('../data/timeline.seed.json', import.meta.url), 'utf8'));
  assert.equal(seed.entries.length, 81); assert.equal(new Set(seed.entries.map(e => e.stableId)).size, 81);
  assert.equal(seed.entries[0].originalTitle, 'Eyes of Wakanda'); assert.equal(seed.entries.at(-1).originalTitle, 'VisionQuest');
  assert.equal(seed.entries.filter(e => e.originalTitle === 'Daredevil').length, 3);
  assert(seed.entries.every(e => !e.tmdbId && e.chronologySource[0].url.startsWith('https://www.marvel.com/')));
});
test('identity resolution refuses ambiguous exact matches', async () => {
  const timeline = new Timeline({ trakt: { pages: async () => [1, 2].map(id => ({ movie: { title: 'Fixture', year: 2020, ids: { trakt: id, tmdb: id } } })) }, store: {} });
  await assert.rejects(timeline.identify({ mediaType: 'movie', originalTitle: 'Fixture', searchYear: 2020, stableId: 'fixture' }), /IDENTITY_REVIEW_REQUIRED/);
});

test('watch sync uses last activities and reloads only the changed watched collection', async () => {
  let stored;
  let episodeStamp = 'v1';
  const calls = [];
  const sync = new WatchSync({
    get: async (path, query) => {
      calls.push(path);
      if (path === '/sync/watched/shows') assert.deepEqual(query, { extended: 'progress' });
      if (path === '/sync/last_activities') return { data: { movies: { watched_at: 'v1', paused_at: 'v1' }, episodes: { watched_at: episodeStamp, paused_at: 'v1' } } };
      return { data: path.endsWith('watching') ? null : [] };
    },
    pages: async path => { calls.push(path); return []; }
  }, { read: async () => stored, write: async (_, value) => { stored = value; } });
  await sync.load();
  calls.length = 0;
  episodeStamp = 'v2';
  await sync.load(true);
  assert.deepEqual(calls, ['/sync/last_activities', '/sync/watched/shows', '/users/me/watching']);
});
