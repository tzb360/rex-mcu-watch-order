import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import { readFile } from 'node:fs/promises';
const source = await readFile(new URL('../widget/mcu-watch-order-local.js', import.meta.url), 'utf8');
function runtime(http) {
  const data = new Map();
  const context = vm.createContext({ Widget: { storage: { get: async key => data.get(key), set: async (key, value) => data.set(key, value) }, http } });
  vm.runInContext(source, context);
  return { context, data };
}
test('local build is a standalone script with exactly one core module and no private credentials', () => {
  const { context } = runtime({});
  assert.equal(context.WidgetMetadata.modules.length, 1);
  assert.equal(typeof context.loadMcuLocal, 'function');
  assert.doesNotMatch(source, /^import |^export |\bimport\.meta|\bcreateHash\(|\breadFile\(/m);
  assert.doesNotMatch(source, /MCU_ACCESS_KEY|MCU_ADMIN_KEY|client_secret\s*[:=]/);
});
test('local diagnosis checks Widget storage/HTTP without asking for user data', async () => {
  const urls = [];
  const { context } = runtime({ get: async url => { urls.push(url); return { statusCode: 200, data: { ids: { tmdb: 1 } } }; } });
  const items = await context.loadMcuLocal({ action: 'diagnose' });
  assert.match(items[0].title, /存储读写=成功/); assert.match(items[0].title, /Trakt GET=200/);
  assert.equal(items[0].type, 'url'); assert.equal(items[0].mediaType, undefined);
  assert.match(items[0].title, /时间线=时间线 JSON 格式不符合要求/);
  assert.deepEqual(urls, ['https://api.trakt.tv/movies/iron-man-2008', context.MCU_SEED_URL]);
});
test('device flow only posts public client ID, keeps device secret out of returned card, reuses unexpired code', async () => {
  let hits = 0;
  const { context, data } = runtime({ post: async (url, body) => {
    hits++; assert.equal(url, 'https://auth.trakt.tv/oauth/device/code');
    assert.deepEqual(Object.keys(body), ['client_id']);
    return { statusCode: 200, data: { device_code: 'PRIVATE_DEVICE_FIXTURE', user_code: 'ABCD1234', verification_url: 'https://auth.trakt.tv/activate', expires_in: 600, interval: 5 } };
  } });
  const first = await context.loadMcuLocal({ action: 'connect' });
  const again = await context.loadMcuLocal({ action: 'connect' });
  assert.match(first[0].title, /ABCD1234/); assert.doesNotMatch(JSON.stringify(first), /PRIVATE_DEVICE_FIXTURE/);
  assert.equal(again[0].title, first[0].title); assert.equal(hits, 1);
  assert(data.has('mcu.local.v2.private.device'));
});
test('device flow rejects a foreign verification destination', async () => {
  const { context } = runtime({ post: async () => ({ statusCode: 200, data: { device_code: 'private', user_code: 'fixture', verification_url: 'https://evil.example/activate', expires_in: 600, interval: 5 } }) });
  const out = await context.loadMcuLocal({ action: 'connect' });
  assert.match(out[0].description, /不是 Trakt 官方域名/);
});
test('token exchange stays in local storage and never enters display card', async () => {
  const { context, data } = runtime({ post: async (url, body) => {
    assert.equal(url, 'https://auth.trakt.tv/oauth/device/token'); assert.equal(body.code, 'private-device');
    return { statusCode: 200, data: { access_token: 'PRIVATE_ACCESS_FIXTURE', refresh_token: 'PRIVATE_REFRESH_FIXTURE', created_at: Math.floor(Date.now() / 1000), expires_in: 604800 } };
  } });
  data.set('mcu.local.v2.private.device', JSON.stringify({ device_code: 'private-device', nextPollAt: 0, expiresAt: Date.now() + 60000, interval: 5 }));
  const result = await context.loadMcuLocal({ action: 'confirm' });
  assert.match(result[0].title, /连接成功/); assert.doesNotMatch(JSON.stringify(result), /PRIVATE_(ACCESS|REFRESH)_FIXTURE/);
  assert.match(data.get('mcu.local.v2.private.tokens'), /PRIVATE_ACCESS_FIXTURE/);
});
test('user-driven device polling respects interval and keeps pending state', async () => {
  let hits = 0;
  const { context, data } = runtime({ post: async () => { hits++; throw new Error('should not poll'); } });
  data.set('mcu.local.v2.private.device', JSON.stringify({ device_code: 'private', nextPollAt: Date.now() + 5000, expiresAt: Date.now() + 60000, interval: 5 }));
  const result = await context.loadMcuLocal({ action: 'confirm' });
  assert.match(result[0].title, /等待/); assert.equal(hits, 0);
});
test('corrupt local token data never appears in a user-facing error', async () => {
  const { context, data } = runtime({});
  data.set('mcu.local.v2.private.tokens', 'INVALID_PRIVATE_TOKEN_FIXTURE');
  const result = await context.loadMcuLocal({ action: 'watch' });
  assert.match(result[0].description, /缓存损坏/); assert.doesNotMatch(JSON.stringify(result), /INVALID_PRIVATE_TOKEN_FIXTURE/);
});
test('first list load checkpoints a bounded batch and refresh resumes the next entry', async () => {
  const seed = JSON.parse(await readFile(new URL('../data/timeline.seed.json', import.meta.url), 'utf8'));
  const urls = [];
  const { context, data } = runtime({ get: async url => {
    urls.push(url);
    return { statusCode: 200, data: seed };
  } });
  data.set('mcu.local.v2.private.tokens', JSON.stringify({ access_token: 'fixture' }));
  vm.runInContext(`Timeline.prototype.enrich = async function (entry) {
    return { ...entry, metadataVerifiedAt: new Date().toISOString() };
  };`, context);

  const first = await context.loadMcuLocal({ action: 'watch' });
  assert.match(first[0].title, /8\/81/);
  assert.equal(data.has('mcu.local.v2.timeline'), false);
  const second = await context.loadMcuLocal({ action: 'watch' });
  assert.match(second[0].title, /16\/81/);
  assert.deepEqual(Object.keys(JSON.parse(data.get('mcu.local.v2.metadata-cache'))), seed.entries.slice(0, 16).map(entry => entry.stableId));
  assert.deepEqual(urls, [context.MCU_SEED_URL]);
});

test('published catalog refresh uses ETags and keeps cached queue on invalid data and network failure', async () => {
  const seed = JSON.parse(await readFile(new URL('../data/timeline.public.json', import.meta.url), 'utf8'));
  let requests = 0;
  const { context, data } = runtime({ get: async (url, options) => {
    assert.equal(url, context.MCU_SEED_URL);
    requests++;
    if (requests === 1) return { statusCode: 200, data: seed, headers: { ETag: '"v1"' } };
    if (requests === 4) throw new Error('offline');
    assert.equal(options.headers['If-None-Match'], '"v1"');
    assert.equal(options.headers['Cache-Control'], 'no-cache');
    if (requests === 2) return { statusCode: 304 };
    return { statusCode: 200, data: { ...seed, entries: Array(81).fill(seed.entries[0]) } };
  } });
  data.set('mcu.local.v2.private.tokens', JSON.stringify({ access_token: 'fixture' }));
  data.set('mcu.local.v2.watched', JSON.stringify({ movies: [], shows: [], playback: [], syncedAt: new Date().toISOString() }));
  const initial = (await context.loadMcuLocal({}))[0];
  assert.equal(initial.title, 'Eyes of Wakanda');
  assert.equal(initial.season, 1);
  assert.equal(initial.episode, 1);
  await context.loadMcuLocal({});
  assert.equal(requests, 1);
  for (let attempt = 2; attempt <= 4; attempt++) {
    assert.equal((await context.loadMcuLocal({ action: 'catalog' }))[0].id, initial.id);
    const cached = JSON.parse(data.get('mcu.local.v2.public-catalog'));
    assert.equal(cached.seed.version, seed.version);
    assert.equal(Boolean(cached.warning), attempt !== 2);
  }
  assert.equal(requests, 4);
});

test('a newly published catalog replaces order without resyncing personal data', async () => {
  const seed = JSON.parse(await readFile(new URL('../data/timeline.public.json', import.meta.url), 'utf8'));
  const entries = structuredClone(seed.entries);
  [entries[0].timelineOrder, entries[1].timelineOrder] = [entries[1].timelineOrder, entries[0].timelineOrder];
  let requests = 0;
  const { context, data } = runtime({ get: async url => {
    assert.equal(url, context.MCU_SEED_URL);
    return { statusCode: 200, data: ++requests === 1 ? seed : { ...seed, entries, version: 'test-new', updatedAt: '2099-01-01T00:00:00Z' } };
  } });
  data.set('mcu.local.v2.private.tokens', JSON.stringify({ access_token: 'fixture' }));
  data.set('mcu.local.v2.watched', JSON.stringify({ movies: [], shows: [], playback: [], syncedAt: new Date().toISOString() }));
  assert.equal((await context.loadMcuLocal({}))[0].title, 'Eyes of Wakanda');
  assert.equal((await context.loadMcuLocal({ action: 'catalog' }))[0].title, 'Captain America: The First Avenger');
  assert.equal(JSON.parse(data.get('mcu.local.v2.public-catalog')).seed.version, 'test-new');
});

test('Rex cards keep native TMDB titles, overview and art separate from episode progress', async () => {
  const seed = JSON.parse(await readFile(new URL('../data/timeline.public.json', import.meta.url), 'utf8'));
  const { context, data } = runtime({ get: async () => ({ statusCode: 200, data: seed }) });
  data.set('mcu.local.v2.private.tokens', JSON.stringify({ access_token: 'fixture' }));
  data.set('mcu.local.v2.watched', JSON.stringify({ movies: [], shows: [], playback: [], syncedAt: new Date().toISOString() }));
  context.Widget.tmdb = { get: async path => ({ data: {
    id: Number(path.split('/')[1]), name: '原剧名', overview: '官方原简介。', poster_path: '/poster.jpg', backdrop_path: '/backdrop.jpg'
  } }) };
  const first = (await context.loadMcuLocal({}))[0];
  assert.equal(first.title, '原剧名');
  assert.equal(first.id, String(seed.entries[0].tmdbId));
  assert.equal(first.tmdbId, seed.entries[0].tmdbId);
  assert.equal(first.description, '官方原简介。');
  assert.equal(first.posterPath, '/poster.jpg');
  assert.equal(first.backdropPath, '/backdrop.jpg');
  assert.equal(first.episode, 1);
  assert.equal(first.season, 1);
});
