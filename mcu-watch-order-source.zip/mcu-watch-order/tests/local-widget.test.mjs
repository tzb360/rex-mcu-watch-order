import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import { readFile } from 'node:fs/promises';
const source = await readFile(new URL('../widget/mcu-watch-order-local.js', import.meta.url), 'utf8');
function runtime(http) {
  const data = new Map();
  const context = vm.createContext({ Widget: { storage: { get: async key => data.get(key), set: async (key, value) => data.set(key, value) }, http } });
  vm.runInContext(source, context);
  return { context, data };
}
test('local build is a standalone script with exactly one core module and no private credentials', () => {
  const { context } = runtime({});
  assert.equal(context.WidgetMetadata.modules.length, 1);
  assert.equal(typeof context.loadMcuLocal, 'function');
  assert.doesNotMatch(source, /^import |^export |\bimport\.meta|\bcreateHash\(|\breadFile\(/m);
  assert.doesNotMatch(source, /MCU_ACCESS_KEY|MCU_ADMIN_KEY|client_secret\s*[:=]/);
});
test('local diagnosis checks Widget storage/HTTP without asking for user data', async () => {
  const urls = [];
  const { context } = runtime({ get: async url => { urls.push(url); return { statusCode: 200, data: { ids: { tmdb: 1 } } }; } });
  const items = await context.loadMcuLocal({ action: 'diagnose' });
  assert.match(items[0].title, /存储读写=成功/); assert.match(items[0].title, /Trakt GET=200/);
  assert.equal(items[0].type, 'url'); assert.equal(items[0].mediaType, undefined);
  assert.deepEqual(urls, ['https://api.trakt.tv/movies/iron-man-2008']);
});
test('device flow only posts public client ID, keeps device secret out of returned card, reuses unexpired code', async () => {
  let hits = 0;
  const { context, data } = runtime({ post: async (url, body) => {
    hits++; assert.equal(url, 'https://auth.trakt.tv/oauth/device/code');
    assert.deepEqual(Object.keys(body), ['client_id']);
    return { statusCode: 200, data: { device_code: 'PRIVATE_DEVICE_FIXTURE', user_code: 'ABCD1234', verification_url: 'https://auth.trakt.tv/activate', expires_in: 600, interval: 5 } };
  } });
  const first = await context.loadMcuLocal({ action: 'connect' });
  const again = await context.loadMcuLocal({ action: 'connect' });
  assert.match(first[0].title, /ABCD1234/); assert.doesNotMatch(JSON.stringify(first), /PRIVATE_DEVICE_FIXTURE/);
  assert.equal(again[0].title, first[0].title); assert.equal(hits, 1);
  assert(data.has('mcu.local.v2.private.device'));
});
test('device flow rejects a foreign verification destination', async () => {
  const { context } = runtime({ post: async () => ({ statusCode: 200, data: { device_code: 'private', user_code: 'fixture', verification_url: 'https://evil.example/activate', expires_in: 600, interval: 5 } }) });
  const out = await context.loadMcuLocal({ action: 'connect' });
  assert.match(out[0].description, /不是 Trakt 官方域名/);
});
test('token exchange stays in local storage and never enters display card', async () => {
  const { context, data } = runtime({ post: async (url, body) => {
    assert.equal(url, 'https://auth.trakt.tv/oauth/device/token'); assert.equal(body.code, 'private-device');
    return { statusCode: 200, data: { access_token: 'PRIVATE_ACCESS_FIXTURE', refresh_token: 'PRIVATE_REFRESH_FIXTURE', created_at: Math.floor(Date.now() / 1000), expires_in: 604800 } };
  } });
  data.set('mcu.local.v2.private.device', JSON.stringify({ device_code: 'private-device', nextPollAt: 0, expiresAt: Date.now() + 60000, interval: 5 }));
  const result = await context.loadMcuLocal({ action: 'confirm' });
  assert.match(result[0].title, /连接成功/); assert.doesNotMatch(JSON.stringify(result), /PRIVATE_(ACCESS|REFRESH)_FIXTURE/);
  assert.match(data.get('mcu.local.v2.private.tokens'), /PRIVATE_ACCESS_FIXTURE/);
});
test('user-driven device polling respects interval and keeps pending state', async () => {
  let hits = 0;
  const { context, data } = runtime({ post: async () => { hits++; throw new Error('should not poll'); } });
  data.set('mcu.local.v2.private.device', JSON.stringify({ device_code: 'private', nextPollAt: Date.now() + 5000, expiresAt: Date.now() + 60000, interval: 5 }));
  const result = await context.loadMcuLocal({ action: 'confirm' });
  assert.match(result[0].title, /等待/); assert.equal(hits, 0);
});
test('corrupt local token data never appears in a user-facing error', async () => {
  const { context, data } = runtime({});
  data.set('mcu.local.v2.private.tokens', 'INVALID_PRIVATE_TOKEN_FIXTURE');
  const result = await context.loadMcuLocal({ action: 'watch' });
  assert.match(result[0].description, /缓存损坏/); assert.doesNotMatch(JSON.stringify(result), /INVALID_PRIVATE_TOKEN_FIXTURE/);
});
