import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { Timeline, normalize } from '../src/timeline.mjs';
const seed = JSON.parse(await readFile(new URL('../data/timeline.seed.json', import.meta.url), 'utf8'));
const html = labels => '<h4>MCU Complete Timeline</h4><ul>' + labels.map(label => '<li>' + label.replaceAll('&', '&amp;') + '</li>').join('') + '</ul>';
const labels = seed.entries.map(e => e.officialLabel);
test('identity normalization retains meaningful Marvel title words and only strips branding prefixes', () => {
  assert.notEqual(normalize('Captain Marvel'), normalize('Captain'));
  assert.notEqual(normalize('Marvel Zombies'), normalize('Zombies'));
  assert.equal(normalize("Marvel's Daredevil"), normalize('Daredevil'));
  assert.equal(normalize('Marvel Studios One Shot: Agent Carter'), normalize('Marvel One-Shot: Agent Carter'));
});
function memory() {
  const data = new Map();
  return { data, read: async key => data.get(key) || null, write: async (key, value) => data.set(key, structuredClone(value)) };
}
test('E: new unambiguous officially listed movie is added in official position', async () => {
  const store = memory();
  const next = [...labels]; next.splice(10, 0, 'Fixture New Movie');
  const t = new Timeline({ store, fetchImpl: async () => new Response(html(next)), trakt: { pages: async path => path.includes('/movie/') ? [{ movie: { title: 'Fixture New Movie', year: 2026, ids: { trakt: 999, tmdb: 999 } } }] : [] } });
  const result = await t.checkOfficial(seed);
  assert.equal(result.entries.length, 82); assert.equal(result.entries[10].traktId, 999);
  assert.equal(result.entries[10].universe, 'official-unclassified');
});
test('new season retains the same show identity and gets its own timeline slot', async () => {
  const store = memory();
  const next = [...labels, 'Loki S3'];
  const t = new Timeline({ store, fetchImpl: async () => new Response(html(next)), trakt: {} });
  const result = await t.checkOfficial(seed);
  assert.equal(result.entries.at(-1).season, 3); assert.equal(result.entries.at(-1).originalTitle, 'Loki');
  assert.equal(result.entries.at(-1).stableId, 'mcu-loki-s3');
});
test('ambiguous new title is quarantined with an explicit review count', async () => {
  const store = memory();
  const t = new Timeline({ store, fetchImpl: async () => new Response(html([...labels, 'Ambiguous Fixture'])), trakt: { pages: async path => path.includes('/movie/') ? [1, 2].map(id => ({ movie: { title: 'Ambiguous Fixture', ids: { trakt: id, tmdb: id } } })) : [] } });
  const result = await t.checkOfficial(seed);
  assert.equal(result.entries.length, 81); assert.equal(result.pendingReview, 1);
  assert.equal((await store.read('timeline-proposals')).proposals.length, 1);
});
test('official removal cannot silently overwrite the verified timeline', async () => {
  const t = new Timeline({ store: memory(), fetchImpl: async () => new Response(html(labels.slice(1))), trakt: {} });
  await assert.rejects(t.checkOfficial(seed), /REMOVAL_REVIEW_REQUIRED/);
});
test('G: failed metadata update leaves current timeline untouched and checkpoints progress', async () => {
  const store = memory(); await store.write('timeline', seed);
  const t = new Timeline({ store, fetchImpl: async () => { throw new Error('OFFLINE'); }, trakt: {} });
  let count = 0;
  t.enrich = async entry => { if (++count === 3) throw new Error('NETWORK'); return { ...entry, metadataVerifiedAt: new Date().toISOString() }; };
  await assert.rejects(t.update(), /NETWORK/);
  assert.equal((await store.read('timeline')).version, seed.version);
  assert.equal(Object.keys(await store.read('metadata-cache')).length, 2);
  assert.equal((await store.read('update-status')).success, false);
});
