var WidgetMetadata = {
  id: 'personal.mcu.timeline',
  title: '漫威宇宙时间线（MCU Watch Order）',
  description: '按漫威官方故事时间线展示待看电影与分季剧集，通过个人后端同步 Trakt。Trakt 数据来源：trakt.tv。',
  author: 'Personal MCU Timeline',
  site: 'https://www.marvel.com/articles/movies/mcu-timeline-order-disney-plus',
  version: '0.1.0', requiredVersion: '0.0.1', detailCacheDuration: 60,
  modules: [{
    id: 'mcu-watch-order', title: '漫威宇宙观影顺序',
    description: '最早未完成的作品排在首位。填写个人 HTTPS 服务和只读密钥。',
    functionName: 'loadMcuTimeline', requiresWebView: false, cacheDuration: 0,
    params: [
      { name: 'endpoint', title: '个人 API 地址', type: 'input', value: '', description: '填写 https://你的域名/mcu。' },
      { name: 'accessKey', title: '个人只读访问密钥', type: 'input', value: '', description: '只读后端密钥；不要填写 Trakt Token 或管理密钥。此字段可能明文显示。' },
      { name: 'refresh', title: '观看状态刷新', type: 'enumeration', value: 'cached', enumOptions: [{ title: '正常刷新（10分钟缓存）', value: 'cached' }, { title: '立即重新同步', value: 'force' }] },
      { name: 'page', title: '页码', type: 'page', value: '1' }
    ]
  }]
};
function mcuFingerprint(value) {
  var hash = 2166136261;
  for (var i = 0; i < value.length; i++) hash = Math.imul(hash ^ value.charCodeAt(i), 16777619);
  return String(hash >>> 0);
}
async function mcuEnrich(item) {
  if (!Widget.tmdb || !Widget.tmdb.get) return item;
  try {
    var raw = await Widget.tmdb.get(item.id.replace('.', '/'), { params: { language: 'zh-CN' } });
    var metadata = raw && raw.data !== undefined ? raw.data : raw;
    if (typeof metadata === 'string') metadata = JSON.parse(metadata);
    if (!metadata || Number(metadata.id) !== Number(item.id.split('.')[1])) return item;
    var title = metadata.title || metadata.name;
    if (title) item.title = title + item.title.slice(item.title.indexOf(' · ') >= 0 ? item.title.indexOf(' · ') : item.title.length);
    item.posterPath = metadata.poster_path || item.posterPath;
    item.backdropPath = metadata.backdrop_path || item.backdropPath;
    if (metadata.overview) item.description += '\n' + metadata.overview;
  } catch (_) { /* Native TMDB details remain available. */ }
  return item;
}
async function loadMcuTimeline(params) {
  params = params || {};
  var endpoint = String(params.endpoint || '').replace(/\/+$/, '');
  var key = String(params.accessKey || '');
  if (!/^https:\/\/[^\s/?#@]+(?:\/[^\s?#]*)?$/.test(endpoint) || !/\/mcu$/.test(endpoint)) throw new Error('请配置个人 HTTPS API 地址，以 /mcu 结尾。');
  if (key.length < 32) throw new Error('请填写个人后端的只读访问密钥。');
  var page = Number(params.page || 1);
  if (!Number.isInteger(page) || page < 1) throw new Error('页码无效。');
  var storageKey = 'mcu.queue.v1.' + mcuFingerprint(endpoint + '|' + key);
  var payload;
  try {
    var response = await Widget.http.get(endpoint + '/v1/queue', { headers: { Authorization: 'Bearer ' + key }, params: { refresh: params.refresh === 'force' && page === 1 ? '1' : '0' } });
    var status = response.statusCode || response.status || 200;
    if (status === 401 || status === 403) throw new Error('AUTH_INVALID');
    payload = response.data;
    if (typeof payload === 'string') payload = JSON.parse(payload);
    if (payload && /TRAKT_(REAUTHORIZE|AUTH_REQUIRED|UNAUTHORIZED)/.test(payload.error || '')) throw new Error('TRAKT_REAUTHORIZE');
    if (payload && payload.error === 'TIMELINE_SETUP_REQUIRED') throw new Error('TIMELINE_SETUP_REQUIRED');
    if (status >= 400 || !payload || !Array.isArray(payload.items) || !payload.syncedAt) throw new Error('REMOTE_UNAVAILABLE');
    for (var i = 0; i < payload.items.length; i++) {
      var entry = payload.items[i];
      if (!/^(movie|tv)\.\d+$/.test(entry.id) || entry.type !== 'tmdb' || entry.mediaType !== entry.id.split('.')[0]) throw new Error('REMOTE_INVALID_ITEM');
    }
    if (Widget.storage && Widget.storage.set) await Widget.storage.set(storageKey, JSON.stringify(payload));
  } catch (error) {
    if (error.message === 'AUTH_INVALID') throw new Error('个人 API 密钥无效或已撤销，请检查配置。');
    if (error.message === 'TRAKT_REAUTHORIZE') throw new Error('Trakt 需要重新授权；已保存观看记录保留。');
    if (error.message === 'TIMELINE_SETUP_REQUIRED') throw new Error('服务器尚未完成媒体 ID 与分集数据核实，请先完成初始化。');
    var saved = Widget.storage && Widget.storage.get ? await Widget.storage.get(storageKey) : null;
    try { payload = typeof saved === 'string' ? JSON.parse(saved) : saved; } catch (_) { payload = null; }
    if (!payload || !Array.isArray(payload.items)) throw new Error('个人服务暂时不可用，尚无有效缓存。');
    payload.warning = '网络异常，使用上次有效缓存；Trakt 同步于 ' + payload.syncedAt;
    payload.items = payload.items.map(function (item) { return Object.assign({}, item, { description: payload.warning + '\n' + item.description }); });
  }
  if (!payload.items.length && page === 1) throw new Error(payload.emptyMessage || '当前已核实、已发行的 MCU 时间线已全部完成。');
  var slice = payload.items.slice((page - 1) * 30, page * 30);
  var output = [];
  for (var offset = 0; offset < slice.length; offset += 3) output = output.concat(await Promise.all(slice.slice(offset, offset + 3).map(mcuEnrich)));
  if (payload.warning && output.length) output[0].title = '【同步提示】' + output[0].title;
  return output;
}
