// This file is concatenated with shared, tested core code by build-local.mjs.
// Trakt Client ID is public. No account token or client secret is distributed.
var MCU_CLIENT_ID = 'jik3qry8gfgZ1jhnC8txpNYnoA1eImB_zz-nBDtGbiI';
var MCU_SEED_URL = 'https://raw.githubusercontent.com/tzb360/rex-mcu-watch-order/main/timeline.seed.json';
var WidgetMetadata = {
  id: 'personal.mcu.timeline.local', title: '漫威宇宙时间线 · 本地版',
  description: '按漫威故事顺序显示下一部和下一集。时间线通过 HTTPS 更新，观看进度由 Rex 直接从 Trakt 同步。',
  author: 'Personal MCU Timeline', site: 'https://www.marvel.com/articles/movies/mcu-timeline-order-disney-plus',
  version: '0.2.3', requiredVersion: '0.0.1', detailCacheDuration: 60,
  modules: [{
    id: 'mcu-local', title: '漫威宇宙观影顺序', functionName: 'loadMcuLocal', cacheDuration: 0, requiresWebView: false,
    params: [
      { name: 'action', title: '操作', type: 'enumeration', value: 'watch', enumOptions: [
        { title: '查看待看清单', value: 'watch' }, { title: '连接 Trakt', value: 'connect' },
        { title: '我已完成授权', value: 'confirm' }, { title: '立即同步观看记录', value: 'refresh' },
        { title: '刷新时间线', value: 'catalog' }, { title: '检查运行环境', value: 'diagnose' }
      ] },
      { name: 'seedUrl', title: '时间线数据地址', type: 'input', value: MCU_SEED_URL, description: '只填写可信的公开 HTTPS JSON 地址；不携带个人观看数据或凭据。' },
      { name: 'page', title: '页码', type: 'page', value: '1' }
    ]
  }]
};

function MCUQuery(values) {
  this.toString = function () { return Object.keys(values).map(function (key) { return encodeURIComponent(key) + '=' + encodeURIComponent(String(values[key])); }).join('&'); };
}
function mcuVersion(value) {
  var result = 2166136261;
  for (var i = 0; i < value.length; i++) result = Math.imul(result ^ value.charCodeAt(i), 16777619);
  return (result >>> 0).toString(16);
}
var mcuLocalStore = {
  read: async function (key) {
    var value = await Widget.storage.get('mcu.local.v2.' + key);
    if (value == null || value === '') return null;
    try { return typeof value === 'string' ? JSON.parse(value) : value; }
    catch (_) { throw new Error('本地模块缓存损坏，请重新连接 Trakt；不会输出缓存原文。'); }
  },
  write: async function (key, value) { await Widget.storage.set('mcu.local.v2.' + key, JSON.stringify(value)); },
  readSecret: async function (key) { return this.read('private.' + key); },
  writeSecret: async function (key, value) { return this.write('private.' + key, value); }
};
async function mcuNativeFetch(url, options) {
  options = options || {};
  var response;
  var request = { headers: options.headers || {}, timeout: 6 };
  if (options.method === 'POST') {
    response = await Widget.http.post(url, options.body ? JSON.parse(options.body) : {}, request);
  } else {
    response = await Widget.http.get(url, request);
  }
  var status = Number(response.statusCode || response.status || 200);
  var data = response.data;
  var headers = response.headers || {};
  return {
    status: status, ok: status >= 200 && status < 300,
    headers: { get: function (key) { var found = Object.keys(headers).find(function (k) { return k.toLowerCase() === key.toLowerCase(); }); return found ? String(headers[found]) : null; } },
    text: async function () { return data == null ? '' : typeof data === 'string' ? data : JSON.stringify(data); },
    json: async function () { return typeof data === 'string' ? JSON.parse(data) : data; }
  };
}
var mcuLocalTrakt = null;
var mcuLocalSync = null;
var mcuLocalOperations = new Map();
var mcuLocalOperation = Promise.resolve();
function mcuLocalStatus(message, link) {
  var url = link || 'https://developer.trakt.tv/apps';
  return [{ id: url, type: 'url', title: message.split('\n')[0], description: message, link: url }];
}

async function mcuAuthorizeDevice(action) {
  var pending = await mcuLocalStore.readSecret('device');
  var now = Date.now();
  if (action === 'connect') {
    if (!pending || now >= pending.expiresAt) {
      var code = await mcuLocalTrakt.oauth('/oauth/device/code', { client_id: MCU_CLIENT_ID });
      if (!code.device_code || !code.user_code || !code.verification_url || !Number.isFinite(code.interval) || !Number.isFinite(code.expires_in)) throw new Error('设备码接口未返回完整响应。');
      if (!/^https:\/\/(?:auth\.)?trakt\.tv(?:\/|$)/.test(code.verification_url)) throw new Error('授权链接不是 Trakt 官方域名，已停止。');
      pending = Object.assign({}, code, { expiresAt: now + code.expires_in * 1000, nextPollAt: now + code.interval * 1000 });
      await mcuLocalStore.writeSecret('device', pending);
    }
    return mcuLocalStatus('连接 Trakt：' + pending.user_code + '\n请用浏览器打开 ' + pending.verification_url + '，输入上述代码。授权后将“操作”改为“我已完成授权”再刷新。本地版会将令牌保存于 Rex 模块存储，不上传服务器。', pending.verification_url);
  }
  if (!pending || now >= pending.expiresAt) throw new Error('授权码已过期，请选择“连接 Trakt”重新生成。');
  if (now < pending.nextPollAt) throw new Error('请等待 ' + Math.ceil((pending.nextPollAt - now) / 1000) + ' 秒后再检查授权。');
  // A user-driven poll needs no timers and never polls faster than the provider interval.
  pending.nextPollAt = now + pending.interval * 1000;
  await mcuLocalStore.writeSecret('device', pending);
  try {
    var token = await mcuLocalTrakt.oauth('/oauth/device/token', { code: pending.device_code, client_id: MCU_CLIENT_ID });
    await mcuLocalTrakt.saveToken(token);
    await mcuLocalStore.writeSecret('device', null);
  } catch (error) {
    if (error.code === 'TRAKT_HTTP_400') throw new Error('Trakt 尚未确认授权；请完成网页授权后再刷新。');
    if (error.code === 'TRAKT_RATE_LIMIT') {
      pending.nextPollAt = error.retryAt || now + 60000;
      await mcuLocalStore.writeSecret('device', pending);
    }
    if (['TRAKT_HTTP_404', 'TRAKT_HTTP_409', 'TRAKT_HTTP_410', 'TRAKT_HTTP_418'].indexOf(error.code) >= 0) {
      await mcuLocalStore.writeSecret('device', null);
      throw new Error('授权已失效或被拒绝，请重新连接 Trakt。');
    }
    throw error;
  }
  return mcuLocalStatus('Trakt 已连接成功。请选择“查看待看清单”并刷新。');
}
function mcuValidCatalog(seed) {
  if (!seed || seed.schemaVersion !== 1 || typeof seed.version !== 'string' ||
      !/^[-.a-zA-Z0-9]{1,80}$/.test(seed.version) || !Number.isFinite(Date.parse(seed.updatedAt)) ||
      !Array.isArray(seed.entries) || seed.entries.length < 50 || seed.entries.length > 600) return false;
  var ids = new Set();
  var positions = new Set();
  return seed.entries.every(function (entry) {
    if (!entry || typeof entry.stableId !== 'string' || !entry.stableId || ids.has(entry.stableId) ||
        typeof entry.originalTitle !== 'string' || !entry.originalTitle || !['movie', 'tv'].includes(entry.mediaType) ||
        !Number.isFinite(entry.timelineOrder) || positions.has(entry.timelineOrder) ||
        !Array.isArray(entry.chronologySource) || !entry.chronologySource.some(function (source) { return source && source.url === SOURCE; })) return false;
    ids.add(entry.stableId);
    positions.add(entry.timelineOrder);
    if (seed.metadataStatus !== 'resolved') return seed.metadataStatus === 'requires-live-resolution';
    if (entry.availabilityStatus === 'pending_metadata') return true;
    if (!['released', 'available', 'announced'].includes(entry.availabilityStatus) ||
        !Number.isInteger(entry.tmdbId) || entry.tmdbId <= 0 ||
        (entry.availabilityStatus !== 'announced' && !Number.isFinite(Date.parse(entry.releaseDate)))) return false;
    if (entry.mediaType === 'movie') return true;
    var episodes = entry.episodes;
    return Number.isInteger(entry.season) && Array.isArray(episodes) &&
      (entry.availabilityStatus !== 'available' || episodes.length > 0) &&
      new Set(episodes.map(function (episode) { return episode && episode.number; })).size === episodes.length &&
      episodes.every(function (episode) {
        return episode && episode.season === entry.season && Number.isInteger(episode.number) && episode.number > 0 &&
          (episode.firstAired == null || Number.isFinite(Date.parse(episode.firstAired)));
      });
  }) && (seed.metadataStatus !== 'resolved' || seed.entries.some(function (entry) {
    return ['released', 'available'].includes(entry.availabilityStatus);
  }));
}
async function mcuLoadSeed(url, etag, force) {
  var headers = {};
  if (etag) headers['If-None-Match'] = etag;
  if (force) headers['Cache-Control'] = 'no-cache';
  var response, seed;
  try { response = await mcuNativeFetch(url, { headers: headers }); }
  catch (_) { throw new Error('时间线下载失败：Rex 无法连接数据地址。'); }
  if (response.status === 304) return null;
  if (!response.ok) throw new Error('时间线下载失败：HTTP ' + response.status + '。');
  try { seed = await response.json(); }
  catch (_) { throw new Error('时间线地址没有返回 JSON。'); }
  if (!mcuValidCatalog(seed)) throw new Error('时间线 JSON 格式不符合要求。');
  return { seed: seed, etag: response.headers.get('etag') };
}
async function mcuRefreshCatalog(url, force, cacheOnly) {
  var previous = await mcuLocalStore.read('public-catalog');
  var cached = previous && previous.url === url ? previous : null;
  if (cached && (cacheOnly || (!force && Date.now() < cached.nextCheck))) return cached;
  try {
    var remote = await mcuLoadSeed(url, cached && cached.etag, force);
    if (!remote && !cached) throw new Error('时间线服务器没有返回初始数据。');
    if (remote && cached && cached.seed.metadataStatus === 'resolved' && remote.seed.metadataStatus !== 'resolved') {
      throw new Error('新时间线缺少已核实的元数据。');
    }
    if (remote && cached && Date.parse(remote.seed.updatedAt) < Date.parse(cached.seed.updatedAt)) {
      throw new Error('时间线版本早于本地缓存。');
    }
    var latest = Object.assign({}, remote || cached, { url: url, nextCheck: Date.now() + 30 * 60000, warning: '' });
    await mcuLocalStore.write('public-catalog', latest);
    return latest;
  } catch (error) {
    if (!cached) {
      var legacy = !previous && url === MCU_SEED_URL && await mcuLocalStore.read('timeline');
      if (legacy && legacy.metadataStatus === 'resolved') return { seed: legacy, warning: error.message };
      throw error;
    }
    var fallback = Object.assign({}, cached, { nextCheck: Date.now() + 5 * 60000, warning: error.message });
    await mcuLocalStore.write('public-catalog', fallback);
    return fallback;
  }
}
async function mcuLocalRun(params) {
  if (typeof Widget === 'undefined' || !Widget.http || !Widget.storage || !Widget.storage.get || !Widget.storage.set) throw new Error('此 Rex 运行环境缺少 HTTP 或持久化存储接口，无法运行本地版。');
  var page = Number(params.page || 1);
  if (!Number.isInteger(page) || page < 1) throw new Error('页码无效。');
  mcuLocalTrakt = mcuLocalTrakt || new Trakt({ clientId: MCU_CLIENT_ID, redirectUri: 'http://127.0.0.1:8788/callback', store: mcuLocalStore, fetchImpl: mcuNativeFetch });
  // Persist the provider's backoff between client script invocations.
  mcuLocalTrakt.blockedUntil = await mcuLocalStore.read('blocked-until') || 0;
  var action = params.action || 'watch';
  if (action === 'connect' || action === 'confirm') return mcuAuthorizeDevice(action);
  var seedUrl = String(params.seedUrl || MCU_SEED_URL);
  if (!/^https:\/\/[^\s?#@]+$/.test(seedUrl)) throw new Error('请填写可信的 HTTPS 时间线 JSON 地址。');
  if (action === 'diagnose') {
    var marker = 'storage-check-' + Date.now();
    await mcuLocalStore.write('probe', marker);
    var roundTrip = (await mcuLocalStore.read('probe')) === marker;
    var authorized = Boolean(await mcuLocalStore.readSecret('tokens'));
    var checks = await Promise.allSettled([mcuLocalTrakt.get('/movies/iron-man-2008', {}, false), mcuLoadSeed(seedUrl)]);
    var traktStatus = checks[0].status === 'fulfilled' ? checks[0].value.status : checks[0].reason.code || '失败';
    var seedStatus = checks[1].status === 'fulfilled' ? checks[1].value.seed.version + '，' + checks[1].value.seed.entries.length + ' 个区段' : checks[1].reason.message;
    return mcuLocalStatus('本地诊断：存储读写=' + (roundTrip ? '成功' : '失败') + '；Trakt GET=' + traktStatus + '；时间线=' + seedStatus + '；TMDB=' + Boolean(Widget.tmdb && Widget.tmdb.get) + '；Trakt 授权=' + (authorized ? '已连接' : '未连接') + '。');
  }
  var token = await mcuLocalStore.readSecret('tokens');
  if (!token) throw new Error('请先将“操作”选择为“连接 Trakt”。');
  var catalog = await mcuRefreshCatalog(seedUrl, action === 'catalog' && page === 1, action === 'refresh');
  var timeline = catalog.seed;
  if (timeline.metadataStatus !== 'resolved') {
    var saved = await mcuLocalStore.read('timeline');
    if (saved && saved.catalogUrl === seedUrl && saved.catalogVersion === timeline.version) {
      timeline = saved;
    } else {
      var resolver = new Timeline({ store: mcuLocalStore, trakt: mcuLocalTrakt, fetchImpl: mcuNativeFetch });
      var next = await resolver.update({
        current: Object.assign({}, timeline, { catalogUrl: seedUrl, catalogVersion: timeline.version }),
        maxNewEntries: 8, deadline: Date.now() + 5000, verifyOfficial: false, tolerateMissing: true
      });
      if (next.metadataStatus === 'resolved') timeline = next;
      else if (saved && saved.metadataStatus === 'resolved' && (saved.catalogUrl === seedUrl || (!saved.catalogUrl && seedUrl === MCU_SEED_URL))) timeline = saved;
      else return page === 1 ? mcuLocalStatus('正在核对时间线 ' + next.entries.length + '/' + next.totalEntries + '。刷新可继续。') : [];
    }
  }
  mcuLocalSync = mcuLocalSync || new WatchSync(mcuLocalTrakt, mcuLocalStore, 600000);
  var snapshot = await mcuLocalSync.load(action === 'refresh' && page === 1, action === 'catalog');
  var unresolved = timeline.entries.filter(function (entry) { return entry.availabilityStatus === 'pending_metadata'; }).length;
  var warning = [snapshot.warning, catalog.warning && '使用上次有效时间线：' + catalog.warning,
    unresolved ? unresolved + ' 个区段待核实' : ''].filter(Boolean).join('；');
  var items = buildQueue(timeline, Object.assign({}, snapshot, { warning: warning }));
  if (!items.length && page === 1) return mcuLocalStatus('当前已核实、已发行的 MCU 内容已全部完成。' + warning + '\n时间线 ' + catalog.seed.version);
  var output = items.slice((page - 1) * 30, page * 30);
  for (var item of output) item.description += '\n时间线 ' + catalog.seed.version;
  if (output.length && (action === 'catalog' || warning)) {
    var detail = catalog.warning ? '时间线刷新失败，已使用缓存 ' + catalog.seed.version : '时间线 ' + catalog.seed.version;
    if (snapshot.warning && !catalog.warning) detail += ' · 观看记录使用缓存';
    output[0].title += ' · ' + detail;
  }
  return output;
}
function loadMcuLocal(params) {
  params = params || {};
  var key = JSON.stringify([params.action || 'watch', params.seedUrl || MCU_SEED_URL, Number(params.page || 1)]);
  if (mcuLocalOperations.has(key)) return mcuLocalOperations.get(key);
  var task = mcuLocalOperation.then(function () {
    return mcuLocalRun(params);
  }).catch(function (error) {
    var message = error.message;
    if (error.code === 'TRAKT_NETWORK') message = 'Rex 无法连接 Trakt，请检查网络。';
    if (error.code === 'TRAKT_REAUTHORIZE' || error.code === 'TRAKT_AUTH_REQUIRED') message = 'Trakt 授权已失效，请使用“连接 Trakt”重新授权。';
    if (error.code === 'TRAKT_RATE_LIMIT') message = 'Trakt 请求限流，请于 ' + new Date(error.retryAt).toISOString() + ' 后重试。';
    return mcuLocalStatus('设置或同步提示：' + message);
  }).finally(async function () {
    try {
      if (mcuLocalTrakt && mcuLocalTrakt.blockedUntil) await mcuLocalStore.write('blocked-until', mcuLocalTrakt.blockedUntil);
    } catch (_) { /* Keep the current result if saving rate-limit state fails. */ }
    mcuLocalOperations.delete(key);
  });
  mcuLocalOperations.set(key, task);
  mcuLocalOperation = task;
  return task;
}
