// This file is concatenated with shared, tested core code by build-local.mjs.
// Trakt Client ID is public. No account token or client secret is distributed.
var MCU_CLIENT_ID = 'jik3qry8gfgZ1jhnC8txpNYnoA1eImB_zz-nBDtGbiI';
var MCU_SEED_URL = 'https://raw.githubusercontent.com/tzb360/rex-mcu-watch-order/main/timeline.seed.json';
var WidgetMetadata = {
  id: 'personal.mcu.timeline.local', title: '漫威宇宙时间线 · 本地版',
  description: '本机直接读取 Trakt，不需要常驻 AWS 后端。授权记录保存于 Rex 模块本地存储；未确认其采用系统钥匙串。仅供本人使用。',
  author: 'Personal MCU Timeline', site: 'https://www.marvel.com/articles/movies/mcu-timeline-order-disney-plus',
  version: '0.2.0', requiredVersion: '0.0.1', detailCacheDuration: 60,
  modules: [{
    id: 'mcu-local', title: '漫威宇宙观影顺序', functionName: 'loadMcuLocal', cacheDuration: 0, requiresWebView: false,
    params: [
      { name: 'action', title: '操作', type: 'enumeration', value: 'watch', enumOptions: [
        { title: '查看待看清单', value: 'watch' }, { title: '连接 Trakt', value: 'connect' },
        { title: '我已完成授权', value: 'confirm' }, { title: '立即同步观看记录', value: 'refresh' },
        { title: '更新官方时间线', value: 'catalog' }, { title: '检查运行环境', value: 'diagnose' }
      ] },
      { name: 'seedUrl', title: '时间线数据地址', type: 'input', value: MCU_SEED_URL, description: '只填写可信的公开 HTTPS JSON 地址；不携带个人观看数据或凭据。' },
      { name: 'page', title: '页码', type: 'page', value: '1' }
    ]
  }]
};

function MCUQuery(values) {
  this.toString = function () { return Object.keys(values).map(function (key) { return encodeURIComponent(key) + '=' + encodeURIComponent(String(values[key])); }).join('&'); };
}
function mcuVersion(value) {
  var result = 2166136261;
  for (var i = 0; i < value.length; i++) result = Math.imul(result ^ value.charCodeAt(i), 16777619);
  return (result >>> 0).toString(16);
}
var mcuLocalStore = {
  read: async function (key) {
    var value = await Widget.storage.get('mcu.local.v2.' + key);
    if (value == null || value === '') return null;
    try { return typeof value === 'string' ? JSON.parse(value) : value; }
    catch (_) { throw new Error('本地模块缓存损坏，请重新连接 Trakt；不会输出缓存原文。'); }
  },
  write: async function (key, value) { await Widget.storage.set('mcu.local.v2.' + key, JSON.stringify(value)); },
  readSecret: async function (key) { return this.read('private.' + key); },
  writeSecret: async function (key, value) { return this.write('private.' + key, value); }
};
async function mcuNativeFetch(url, options) {
  options = options || {};
  var response;
  if (options.method === 'POST') {
    response = await Widget.http.post(url, options.body ? JSON.parse(options.body) : {}, { headers: options.headers || {} });
  } else {
    response = await Widget.http.get(url, { headers: options.headers || {} });
  }
  var status = Number(response.statusCode || response.status || 200);
  var data = response.data;
  var headers = response.headers || {};
  return {
    status: status, ok: status >= 200 && status < 300,
    headers: { get: function (key) { var found = Object.keys(headers).find(function (k) { return k.toLowerCase() === key.toLowerCase(); }); return found ? String(headers[found]) : null; } },
    text: async function () { return data == null ? '' : typeof data === 'string' ? data : JSON.stringify(data); },
    json: async function () { return typeof data === 'string' ? JSON.parse(data) : data; }
  };
}
var mcuLocalTrakt = null;
var mcuLocalTimeline = null;
var mcuLocalSync = null;
var mcuLocalOperation = null;
function mcuLocalStatus(message, link) {
  var url = link || 'https://developer.trakt.tv/apps';
  return [{ id: url, type: 'url', title: message.split('\n')[0], description: message, link: url }];
}

async function mcuAuthorizeDevice(action) {
  var pending = await mcuLocalStore.readSecret('device');
  var now = Date.now();
  if (action === 'connect') {
    if (!pending || now >= pending.expiresAt) {
      var code = await mcuLocalTrakt.oauth('/oauth/device/code', { client_id: MCU_CLIENT_ID });
      if (!code.device_code || !code.user_code || !code.verification_url || !Number.isFinite(code.interval) || !Number.isFinite(code.expires_in)) throw new Error('设备码接口未返回完整响应。');
      if (!/^https:\/\/(?:auth\.)?trakt\.tv(?:\/|$)/.test(code.verification_url)) throw new Error('授权链接不是 Trakt 官方域名，已停止。');
      pending = Object.assign({}, code, { expiresAt: now + code.expires_in * 1000, nextPollAt: now + code.interval * 1000 });
      await mcuLocalStore.writeSecret('device', pending);
    }
    return mcuLocalStatus('连接 Trakt：' + pending.user_code + '\n请用浏览器打开 ' + pending.verification_url + '，输入上述代码。授权后将“操作”改为“我已完成授权”再刷新。本地版会将令牌保存于 Rex 模块存储，不上传服务器。', pending.verification_url);
  }
  if (!pending || now >= pending.expiresAt) throw new Error('授权码已过期，请选择“连接 Trakt”重新生成。');
  if (now < pending.nextPollAt) throw new Error('请等待 ' + Math.ceil((pending.nextPollAt - now) / 1000) + ' 秒后再检查授权。');
  // A user-driven poll needs no timers and never polls faster than the provider interval.
  pending.nextPollAt = now + pending.interval * 1000;
  await mcuLocalStore.writeSecret('device', pending);
  try {
    var token = await mcuLocalTrakt.oauth('/oauth/device/token', { code: pending.device_code, client_id: MCU_CLIENT_ID });
    await mcuLocalTrakt.saveToken(token);
    await mcuLocalStore.writeSecret('device', null);
  } catch (error) {
    if (error.code === 'TRAKT_HTTP_400') throw new Error('Trakt 尚未确认授权；请完成网页授权后再刷新。');
    if (error.code === 'TRAKT_RATE_LIMIT') {
      pending.nextPollAt = error.retryAt || now + 60000;
      await mcuLocalStore.writeSecret('device', pending);
    }
    if (['TRAKT_HTTP_404', 'TRAKT_HTTP_409', 'TRAKT_HTTP_410', 'TRAKT_HTTP_418'].indexOf(error.code) >= 0) {
      await mcuLocalStore.writeSecret('device', null);
      throw new Error('授权已失效或被拒绝，请重新连接 Trakt。');
    }
    throw error;
  }
  return mcuLocalStatus('Trakt 已连接成功。请选择“查看待看清单”并刷新。');
}
async function mcuLocalRun(params) {
  if (typeof Widget === 'undefined' || !Widget.http || !Widget.storage || !Widget.storage.get || !Widget.storage.set) throw new Error('此 Rex 运行环境缺少 HTTP 或持久化存储接口，无法运行本地版。');
  var page = Number(params.page || 1);
  if (!Number.isInteger(page) || page < 1) throw new Error('页码无效。');
  mcuLocalTrakt = mcuLocalTrakt || new Trakt({ clientId: MCU_CLIENT_ID, redirectUri: 'http://127.0.0.1:8788/callback', store: mcuLocalStore, fetchImpl: mcuNativeFetch });
  // Persist the provider's backoff between client script invocations.
  mcuLocalTrakt.blockedUntil = await mcuLocalStore.read('blocked-until') || 0;
  var action = params.action || 'watch';
  if (action === 'diagnose') {
    var marker = 'storage-check-' + Date.now();
    await mcuLocalStore.write('probe', marker);
    var roundTrip = (await mcuLocalStore.read('probe')) === marker;
    var result = await mcuLocalTrakt.get('/movies/iron-man-2008', {}, false);
    var authorized = Boolean(await mcuLocalStore.readSecret('tokens'));
    return mcuLocalStatus('本地诊断：存储读写=' + (roundTrip ? '成功' : '失败') + '；Trakt GET=' + result.status + '；TMDB=' + Boolean(Widget.tmdb && Widget.tmdb.get) + '；Trakt 授权=' + (authorized ? '已连接' : '未连接') + '。未读取或修改观看记录。');
  }
  if (action === 'connect' || action === 'confirm') return mcuAuthorizeDevice(action);
  var token = await mcuLocalStore.readSecret('tokens');
  if (!token) throw new Error('请先将“操作”选择为“连接 Trakt”。');
  var seedUrl = String(params.seedUrl || MCU_SEED_URL);
  if (!/^https:\/\/[^\s?#@]+$/.test(seedUrl)) throw new Error('请填写可信的 HTTPS 时间线 JSON 地址。');
  mcuLocalTimeline = new Timeline({ store: mcuLocalStore, trakt: mcuLocalTrakt, fetchImpl: mcuNativeFetch, seedLoader: async function () {
    var response = await mcuNativeFetch(seedUrl);
    if (!response.ok) throw new Error('TIMELINE_SEED_UNAVAILABLE');
    var seed = await response.json();
    if (seed.schemaVersion !== 1 || !Array.isArray(seed.entries) || seed.entries.length < 50 || seed.entries.some(function (e) { return !e.stableId || !e.originalTitle || !Array.isArray(e.chronologySource) || !e.chronologySource.some(function (s) { return s.url === SOURCE; }); })) throw new Error('TIMELINE_SEED_INVALID');
    return seed;
  } });
  var timeline = await mcuLocalTimeline.load();
  var status = await mcuLocalStore.read('update-status');
  var due = !status || (status.success ? Date.now() - Date.parse(status.checkedAt) >= 86400000 : Date.now() >= status.retryAt);
  if (action === 'catalog' || due || timeline.metadataStatus !== 'resolved') {
    try { timeline = await mcuLocalTimeline.update(); }
    catch (error) { if (timeline.metadataStatus !== 'resolved') throw error; }
  }
  mcuLocalSync = mcuLocalSync || new WatchSync(mcuLocalTrakt, mcuLocalStore, 600000);
  var snapshot = await mcuLocalSync.load(action === 'refresh');
  var updateStatus = await mcuLocalStore.read('update-status');
  var warning = [snapshot.warning, timeline.sourceWarning, updateStatus && updateStatus.success === false ? '时间线更新失败，使用上次有效数据' : '', timeline.pendingReview ? timeline.pendingReview + '部新作品待核实' : '', Date.now() - Date.parse(timeline.updatedAt) > 172800000 ? '时间线超过48小时未更新' : ''].filter(Boolean).join('；');
  var items = buildQueue(timeline, Object.assign({}, snapshot, { warning: warning }));
  if (!items.length && page === 1) throw new Error('当前已核实、已发行的 MCU 内容已全部完成。' + warning);
  var selected = items.slice((page - 1) * 30, page * 30);
  var output = [];
  for (var offset = 0; offset < selected.length; offset += 3) output = output.concat(await Promise.all(selected.slice(offset, offset + 3).map(mcuLocalArtwork)));
  if (warning && output.length) output[0].title = '【同步提示】' + output[0].title;
  return output;
}
async function mcuLocalArtwork(item) {
  if (!Widget.tmdb || !Widget.tmdb.get) return item;
  var key = 'artwork.' + item.id;
  var cached = await mcuLocalStore.read(key);
  try {
    if (!cached || Date.now() - cached.checkedAt > 86400000) {
      var response = await Widget.tmdb.get(item.id.replace('.', '/'), { params: { language: 'zh-CN' } });
      var media = response && response.data !== undefined ? response.data : response;
      if (typeof media === 'string') media = JSON.parse(media);
      if (!media || String(media.id) !== item.id.split('.')[1]) throw new Error('TMDB_ID_INVALID');
      cached = { checkedAt: Date.now(), title: media.title || media.name, posterPath: media.poster_path, backdropPath: media.backdrop_path, overview: media.overview };
      await mcuLocalStore.write(key, cached);
    }
  } catch (_) { /* Preserve Trakt identity/details and the previous valid artwork. */ }
  if (cached) {
    if (cached.title) item.title = cached.title + item.title.slice(item.title.indexOf(' · ') >= 0 ? item.title.indexOf(' · ') : item.title.length);
    item.posterPath = cached.posterPath || item.posterPath;
    item.backdropPath = cached.backdropPath || item.backdropPath;
    if (cached.overview) item.description += '\n' + cached.overview;
  }
  return item;
}
async function loadMcuLocal(params) {
  if (mcuLocalOperation) return mcuLocalOperation;
  mcuLocalOperation = mcuLocalRun(params || {}).catch(async function (error) {
    if (mcuLocalTrakt && mcuLocalTrakt.blockedUntil) await mcuLocalStore.write('blocked-until', mcuLocalTrakt.blockedUntil);
    if (error.code === 'TRAKT_NETWORK') throw new Error('Rex 无法连接 Trakt，请检查网络；本地缓存和观看记录保留。');
    if (error.code === 'TRAKT_REAUTHORIZE' || error.code === 'TRAKT_AUTH_REQUIRED') throw new Error('Trakt 授权已失效，请选择“连接 Trakt”重新授权；已有缓存保留。');
    if (error.code === 'TRAKT_RATE_LIMIT') throw new Error('Trakt 请求限流，请于 ' + new Date(error.retryAt).toISOString() + ' 后重试。');
    throw error;
  }).catch(function (error) { return mcuLocalStatus('设置或同步提示：' + error.message); }).finally(async function () {
    if (mcuLocalTrakt && mcuLocalTrakt.blockedUntil) await mcuLocalStore.write('blocked-until', mcuLocalTrakt.blockedUntil);
    mcuLocalOperation = null;
  });
  return mcuLocalOperation;
}
